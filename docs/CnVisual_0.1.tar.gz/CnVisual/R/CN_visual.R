############################################################################################
#' Metodo da Bisse��o:
#' Ilustra as itera��es feitas pelo m�todo da bisse��o, que obtem aproxima��es para as ra�zes de uma dada fun��o real.
#'
#' @param Funcao A equa��o que descreve a fun��o para a qual se deseja encontrar as ra�zes. Ex: exp(x) - x^2 + sqrt(x + 2)
#' @param Intervalo_x Intervalo contento a raiz da fun��o, separado por espa�o, exemplo: -5 6
#' @param N_casas_decimais N�mero de casas decimais correspondente a precisao desejada
#' @param Iteracoes N�mero m�ximo de itera��es
#' @param Tempo Tempo de exibi��o de cada itera��o
#' @param OG_Indices Determina se os �ndices das aproxima��es obtidas em cada itera��o ser�o exibidos ou n�o
#' @param OG_Linha_Axiliar Determina se a linha com o intervalo da itera��o sera exibida ou n�o
BISSECAO <- function()
{
#== Mensagem inicial na �rea de resultados
valuetextm <- "Aproxima��es obtidas"


##================================================================
##========== FUN��ES

#==== Fun�� principal (que faz o m�todo)
bissection <- function(h,...)
{
  #== Valores de entrada
  f<-svalue(env_function)
  pointsentr<-svalue(env_pts)
  plotentr <- svalue(env_plotpts)
  s<-as.numeric(svalue(env_stop))
  stp <- 10^(-s)
  stpint <- as.numeric(svalue(env_inter))
  if(is.na(stpint)) stpint <- 999 #N�mero ilimitado de itera��es
  speed<-as.numeric(svalue(env_speed))


  #=== pegar os valores separados em x
  #
  valxaux <- as.list(strsplit(pointsentr," ")[[1]])
  #intervalo
  a0 <-as.numeric(valxaux[1])
  b0 <- as.numeric(valxaux[2])
  
  valxaux <- as.list(strsplit(plotentr," ")[[1]])
  #intervalo
  plot1 <- as.numeric(valxaux[1])
  plot2 <- as.numeric(valxaux[2])

  func <- paste("func <- function(x){",f,"}")# Criando string de entrada
  eval(parse(text=func))# Transformando o texto salvo na variavel ftext em uma express�o

  fa <- func(a0)
  fb <- func(b0)

  # Vetores para o plot
  a_k <- c()
  b_k <- c()
  fa_k <- c()
  fb_k <- c()
  m_k <- c()

  # Contador de �ndices para while
  cont <- 1

  #=== Garantindo que os pr�-requisitos est�o sendo seguidos exibindo janela de erro
  #
  if(abs(fa)<stp){ # Erro caso o extremo inferior j� satisfa�a o crit�rio de parada
    #== Cria��o da janela de erro
    error.FAMINOR <- gwindow("Erro", width = 15)
    error.FAgt <- ggroup(horizontal = FALSE, container = error.FAMINOR)
    error.FAgb <- ggroup(horizontal = FALSE, container = error.FAMINOR)
    error.FAlabel <- glabel("O extremo inferior do intervalo j� satisfaz o crit�rio de parada", container=error.FAgt)
    exit.FA <-function(h,...){dispose(error.FAMINOR)}
    gbutton("Ok", cont= error.FAgb, handler = exit.FA)
    stop #Parar o c�digo se a janela for criada
  }


  if(abs(fb)<stp){ #Erro caso o extremo superior j� satisfa�a o crit�rio de parada
    #== Cria��o da janela de erro
    error.FBMINOR <- gwindow("Erro", width = 15)
    error.FBgt <- ggroup(horizontal = FALSE, container = error.FBMINOR)
    error.FBgb <- ggroup(horizontal = FALSE, container = error.FBMINOR)
    error.FBlabel <- glabel("O extremo superior do intervalo j� satisfaz o crit�rio de parada", container=error.FBgt)
    exit.FB <-function(h,...){dispose(error.FBMINOR)}
    gbutton("Ok", cont= error.FBgb, handler = exit.FB)
    stop #Parar o c�digo se a janela for criada
  }

  #===Come�o do m�todo em si
  #
  if((fa*fb)<0) # Garantir que o m�todo s� seja feito caso tenha um n�mero impar de ra�zes no intervalo dado
  {
    whilevar <- -1
    while(whilevar == -1) # Garantir que seja feito somente at� que o crit�rio do erro n�o seja satisfeito
    {
      #==Atribui��o dos valores aos vetores
      a_k[cont] <- a0
      b_k[cont] <- b0
      fa_k[cont] <- func(a0)
      fb_k[cont] <- func(b0)
      m_k[cont] <- (a_k[cont]+b_k[cont])/2 #Atribui��o do ponto m�dio


      #== Definir qual ser� o pr�ximo a e b
      if(fa_k[cont]*func(m_k[cont])<0){
        b0 <- m_k[cont]
      }
      else {
        a0 <- m_k[cont]
      }

      #Parar o m�todo pelo while
      if((cont)>=stpint){whilevar <-1}
      if(abs(b0-a0)<stp){whilevar <- 1}
      if(abs(func(m_k[cont]))<stp){whilevar <- 1}
      if(whilevar== -1) cont<- cont + 1 # Aumentar o �ndice do contador
    }

    #= Colocar os valores de entrada de volta em a0 e b0

    a0 <- as.numeric(valxaux[1])
    b0 <- as.numeric(valxaux[2])
    #==== Plot do m�todo
    #
    #Pegar os valores m�ximos e m�nimos da fun��o e for�ar um valor m�nimo e m�ximo para o plot
    y_min <- optimize(func,interval = c(a_k[1]- 1,b_k[1]+ 1)) #y_min pega o valor que d� o m�nimo em x e o valor em y
    y_min <- y_min$objective #y_min agora pega apenas o valor em y
    y_max <- optimize(func,interval = c(a_k[1]- 1,b_k[1]+ 1),maximum = TRUE)
    y_max <- y_max$objective
    absalt <- abs(y_max-y_min) #Altura total do plot

    # Definir uma altura minima nos extremos superiores e inferiores
    if(abs(y_min) <= 0.1*(absalt)) y_min<- -0.1*(absalt)
    if(abs(y_max) <= 0.1*(absalt)) y_max<- 0.1*(absalt)
    inter_y <- c(y_min,y_min) #vetor da altura para o plot das linhas horizontais

    visible(gg) <- TRUE #Agora a �rea gr�fica gg que ir� receber o plot
    plot(func,xlim=c(plot1,plot2), col = "red", xlab="Eixo x", ylab="Eixo y") #Plot da f(x)
    abline(h=0, lty=2)
    abline(v=0, lty=2)

    z_k <- rep(0, cont) # Vetor de zeros do tamanho do vetor m_k

    #= Plot dos pontos a e b sobre o eixo x
    points(a_k[1], 0, col="blue", pch = 1)
    text(a_k[1],0,"a",cex=0.65, pos=3, col="blue")
    points(b_k[1], 0, col="blue", pch = 1)
    text(b_k[1],0,"b",cex=0.65, pos=3, col="blue")

    #== Anima��o
    #
    for (i in 1:cont) #Para cada itera��o
    {
      if(svalue(linhz)){ #linha horizontal
        Sys.sleep(speed/2) #tempo
        inter_x <-c(a_k[i],b_k[i])
        lines(inter_x, inter_y, col="green4", lwd = i + (i-1)*1.2)
        points(inter_x, inter_y,bg ="green4", col="black", pch = 21)
        #--------------------------------------------------------------
      }

      Sys.sleep(speed/2) #tempo
      points(m_k[1:i], z_k[1:i], col="blue", pch = 1) # Plot dos pontos m_k sobre o eixo x

      #
      if(svalue(pont)){ #�ndices dos pontos
        index <-c(0:(i-1))
        text(m_k[1:i],z_k[1:i],index,cex=0.65, pos=3, col="blue")
      }
    }


    #=== Plot do zoom
    dx <- (b0-a0)/10
    visible(gg2) <- TRUE #agora a �rea gr�fica gg2 que ir� receber o plot
    par(mar=rep(0, 4)) #margem
    plot(func, xlim=c(m_k[cont] - dx,m_k[cont] + dx), col = "red", xlab="Eixo x", ylab="Eixo y") #plot da fun��o
    abline(h=0, lty=2)
    abline(v=0, lty=2)

    points(m_k[1:cont], z_k[1:cont], col="blue", pch = 1) # Plot dos pontos m_k sobre o eixo x
    index <-c(0:cont)
    if(svalue(pont)){
      text(m_k[1:cont],z_k[1:cont],index,cex=0.65, pos=3, col="blue")
    }

    #==Resultados a serem mostrados ao usu�rio
    valuetextm <- paste("Aproxima��es: ",paste0(m_k, collapse =" | "))
    insert(mk_output,valuetextm)


  }

  #== Erro para caso tenha um n�mero par de ra�zes
  else{
    error.NoNegative <- gwindow("Erro",width = 10)
    error.NNgt <- ggroup(horizontal = FALSE, container = error.NoNegative)
    error.NNgb <- ggroup(horizontal = FALSE, container = error.NoNegative)
    error.NNlabel <- glabel("No intervalo dado a fun��o n�o tem raiz, tem um n�mero par de ra�zes, ou a raiz e um ponto cr�tico da fun��o. Escolha outro interlavo", container=error.NNgt)
    exit.NN <-function(h,...){dispose(error.NoNegative)}
    gbutton("Ok", cont= error.NNgb, handler = exit.NN)

  }

}


#===========================================================================
#INTERFACE
winbissection <- gwindow("M�todo da Bisse��o") #Cria��o da janela

##= Cria��o dos grupos
Groupbuttons <- ggroup(container = winbissection, horizontal=FALSE)
Groupgraphic <- ggroup(container = winbissection, horizontal=FALSE)

##= Cria��o dos frames
buttonsFrame <- gframe("Dados de Entrada", container = Groupbuttons, horizontal = FALSE)
gbutton("Desenhe", cont= Groupbuttons, handler = bissection)
valueframe <- gframe("Resultados", container = Groupbuttons, hozizontal = TRUE,expand = TRUE)
mk_output <- gtext("", container = valueframe ,expand = TRUE)

##= Cria�ao das op��es gr�ficas
checkboxframe <- gframe("Op��es gr�ficas", container =Groupgraphic, horizontal = TRUE)
glabel("Selecione antes do Plot", container= checkboxframe)
pont <- gcheckbox("�ndices das aproxima��es", checked = FALSE, cont =checkboxframe)
linhz <- gcheckbox("Linha auxiliar", checked = TRUE, cont= checkboxframe, expand = TRUE)

##= Cria��o das �rea do zoom
zoomGraphFrame <- gframe("Zoom do gr�fico principal", container = Groupbuttons, horizontal = FALSE)
gg2<-ggraphics(container = zoomGraphFrame,  width = 220, height = 220)

##= Cria��o da �rea do plot principal
mainGrapghFrame <- gframe("Gr�fico Principal", container = Groupgraphic)
gg<-ggraphics(container = mainGrapghFrame, width = 650, height = 650)

##= �rea de entrada dos dados
functionframe <- gframe("Fun��o", container = buttonsFrame, horizontal = TRUE)
env_function<-gedit("", cont = functionframe, initial.msg = "ex: 2*x + exp(x) - sin(x) + log(x)", expand = TRUE)

stopframe <- gframe("Precis�o desejada", container= buttonsFrame, horizontal=FALSE)
tf1<-ggroup(container = stopframe, horizontal=TRUE )
glabel("N�mero de casas decimais:", container = tf1)
env_stop<-gedit("", cont = tf1, initial.msg = "ex.: 2 para duas casas decimais", expand = TRUE)
tf2<-ggroup(container = stopframe, horizontal=TRUE )
glabel("N�mero m�ximo de itera��es:", container = tf2)
env_inter<-gedit("", cont = tf2, initial.msg = "Preenchimento n�o obrigat�rio", expand = TRUE)

intervalframe <- gframe("Intervalo", container = buttonsFrame, horizontal = TRUE)
glabel("Intervalo no eixo x:", container = intervalframe)
env_pts<-gedit("", width = 20,cont = intervalframe, initial.msg = "Separados por espa�o", expand = TRUE)

intervalplotframe <- gframe("Intervalo de Plot", container = buttonsFrame, horizontal = TRUE)
glabel("No eixo x:", container = intervalplotframe)
env_plotpts<-gedit("", width = 20,cont = intervalplotframe, initial.msg = "Separados por espa�o", expand = TRUE)

sppedframe <- gframe("Velocidade da anima��o", container= buttonsFrame, horizontal=TRUE, expand = TRUE)
glabel("Tempo em segundos:", container = sppedframe)
env_speed<-gedit("",width = 35, cont = sppedframe, initial.msg = "Intervalo de tempo entre as itera��es", expand = TRUE)

##= cria��o do botao de sa�da
exit_func<-function(h,...){dispose(winbissection)}
gbutton("SAIR", cont= Groupbuttons, handler = exit_func)

##= while utilizado na constru��o da anima��o
while(isExtant(winbissection)) Sys.sleep(1)

##= Mudar o �cone da janela
#dir <- dirname(sys.frame(1)$ofile)
#icon_dir <-paste0(dir, "/icon.png")
#img <- gdkPixbufNewFromFile(icon_dir)
#getToolkitWidget(winbissection)$setIcon(img$retval)

}


###########################################################################################
#' M�todo da Falsa Posi��o:
#' Ilustra as itera��es feitas pelo m�todo da falsa posi��o, que obtem aproxima��es para as ra�zes de uma dada fun��o real.
#'
#' @param Funcao A equa��o que descreve a fun��o para a qual se deseja encontrar as ra�zes. Ex: exp(x) - x^2 + sqrt(x + 2)
#' @param Intervalo_x Intervalo contento a raiz da fun��o, separado por espa�o, exemplo: -5 6
#' @param N_Casas N�mero de casas decimais correspondente a precisao desejada
#' @param N_Iteracoes N�mero m�ximo de itera��es
#' @param Tempo Tempo de exibi��o de cada itera��o
#' @param OG_Indices Determina se os �ndices das aproxima��es obtidas em cada itera��o ser�o exibidos ou n�o
#' @param OG_Linha_Secante Determina se as retas secantes ao gr�fico ser�o exibidas ou n�o
FALSAPOSICAO <-function()
{
  #== Mensagem inicial na �rea de resultados
  valuetextm <- "Aproxima��es obtidas"

  ##================================================================
  ##========== FUN��ES

  #==== Fun��o principal (que faz o m�todo)
  falsa <- function(h,...)
  {
    # Valores de entrada
    f<-svalue(env_function)
    pointsentr<-svalue(env_pts)
    plotpts <- svalue(env_plotpts)
    s<-as.numeric(svalue(env_stop))
    stp <- 10^(-s)
    stpint <- as.numeric(svalue(env_inter))
    if(is.na(stpint)) stpint <- 999 #n�mero ilimitado de itera��es
    speed<-as.numeric(svalue(env_speed))

    #=== pegar os valores separados em x
    #
    valxaux <- as.list(strsplit(pointsentr," ")[[1]])
    contval <- length(valxaux) # contador da quantidade de valores de entrada
    #intervalo
    a0 <-as.numeric(valxaux[1])
    b0 <- as.numeric(valxaux[2])
    
    #=== pegar os valores separados em x
    #
    valxaux <- as.list(strsplit(plotpts," ")[[1]])
    #intervalo
    plot1 <- as.numeric(valxaux[1])
    plot2 <- as.numeric(valxaux[2])

    func <- paste("func <- function(x){",f,"}")  # Criando string de entrada
    eval(parse(text=func))  # Transformando o texto salvo na variavel ftext em uma expressao

    fa <- func(a0)     # valor da F(a)
    fb <- func(b0)     # Valor da F(b)

    # Vetores para o plot
    a_k <- c()
    b_k <- c()
    fa_k <- c()
    fb_k <- c()
    m_k <- c()

    # Contador de indices para while
    cont <- 1

    #=== Garantindo que os pr�-requisitos estao sendo seguidos exibindo janela de erro
    #
    if(abs(fa)<stp) # Erro caso o extremo inferior ja satisfaca o criterio de parada
    {
      error.FAMINOR <- gwindow("Erro", width = 15)
      error.FAgt <- ggroup(horizontal = FALSE, container = error.FAMINOR)
      error.FAgb <- ggroup(horizontal = FALSE, container = error.FAMINOR)
      error.FAlabel <- glabel("O extremo inferior do intervalo j� satisfaz o crit�rio de parada", container=error.FAgt)
      exit.FA <-function(h,...){dispose(error.FAMINOR)}
      gbutton("Ok", cont= error.FAgb, handler = exit.FA)
      stop
    }

    if(abs(fb)<stp){ #Erro caso o extremo superior ja satisfa�a o criterio de parada

      error.FBMINOR <- gwindow("Erro", width = 15)
      error.FBgt <- ggroup(horizontal = FALSE, container = error.FBMINOR)
      error.FBgb <- ggroup(horizontal = FALSE, container = error.FBMINOR)
      error.FBlabel <- glabel("O extremo superior do intervalo ja satisfaz o crit�rio de parada", container=error.FBgt)
      exit.FB <-function(h,...){dispose(error.FBMINOR)}
      gbutton("Ok", cont= error.FBgb, handler = exit.FB)
      stop
    }


    #===Comeco do m�todo em si
    #
    if((fa*fb)<0) # If para garantir que o m�todo s� seja feito caso tenha um n�mero impar de ra�zes no intervalo dado
    {
      whilevar <- -1
      while(whilevar == -1) # Garantir que seja feito somente at� que o crit�rio do erro n�o seja satisfeito
      {
        #==Atribui��o dos valores aos vetores
        a_k[cont] <- a0
        b_k[cont] <- b0
        fa_k[cont] <- func(a0)
        fb_k[cont] <- func(b0)
        m_k[cont] <- (a_k[cont]*fb_k[cont] - b_k[cont]*fa_k[cont])/(fb_k[cont] - fa_k[cont]) #Atribui��o do ponto medio


        #== Definir qual sera o proximo a e b
        if(fa_k[cont]*func(m_k[cont])<0){
          b0 <- m_k[cont]
        }
        else {
          a0 <- m_k[cont]
        }

        if((cont>=2)&&(abs(b_k[cont]-a_k[cont])<stp)){whilevar <- 1}
        if(abs(func(m_k[cont]))<stp){whilevar<-1}
        if((cont)>=stpint){whilevar <- 1}
        cont<- cont + 1 # Aumentar o �ndice do contador
      }
      cont <- cont -1

      #==== Plot do m�todo
      #

      y_min <- optimize(func,interval = c(a_k[1],b_k[1])) #y_min pega o valor que d� o m�nimo em x e o valor em y
      y_min <- y_min$objective #y_min agora pega apenas o valor em y
      y_max <- optimize(func,interval = c(a_k[1],b_k[1]),maximum = TRUE)
      y_max <- y_max$objective
      absalt <- abs(y_max-y_min) #Altura total do plot
      absalt <- abs(y_max-y_min) #Altura total do plot

      # Definir uma altura m�nima nos extremos superiores e inferiores
      if(abs(y_min) <= 0.1*(absalt)) y_min<- -0.1*(absalt)
      if(abs(y_max) <= 0.1*(absalt)) y_max<- 0.1*(absalt)

      visible(gg) <- TRUE #Agora a �rea grafica gg que ir� receber o plot
      plot(func, xlim=c(plot1, plot2),ylim=c(y_min,y_max), col = "red", xlab="Eixo x", ylab="Eixo y") #plot da f(x)
      abline(h=0, lty=2)
      abline(v=0, lty=2)

      z_k <- rep(0, cont) # Vetor de zeros do tamanho do vetor m_k

      #= Plot dos pontos a e b sobre o eixo x
      points(a_k[1], 0, col="blue", pch = 1)
      text(a_k[1],0,"a",cex=0.65, pos=3, col="blue")
      points(b_k[1], 0, col="blue", pch = 1)
      text(b_k[1],0,"b",cex=0.65, pos=3, col="blue")



      # Anima��o
      #
      for (i in 1:cont) #Para cada itera��o
      {
        Sys.sleep(speed/3)
        points(m_k[1:i], z_k[1:i], col="blue", pch = 1)# Plot dos pontos m_k sobre o eixo x
        if(svalue(pont)){#�ndices dos pontos
          index <-c(0:(i-1))
          text(m_k[1:i],z_k[1:i],index,cex=0.65, pos=3, col="blue")
        }
        Sys.sleep(speed/3)
        segments(a_k[i],0,a_k[i],fa_k[i], col= "azure4", lty=2)
        if(svalue(linsc)){
          Sys.sleep(speed/3)
          segments(a_k[i],fa_k[i],b_k[i],fb_k[i], col="yellow", lwd = 1.2)
        }
      }


      #=== Plot do zoom
      #
      dx <- (b0-a0)/10
      visible(gg2) <- TRUE #agora a �rea grafica gg2 que ir� receber o plot
      par(mar=rep(0, 4)) #margem
      plot(func, xlim=c(m_k[cont] - dx,m_k[cont] + dx), col = "red", xlab="Eixo x", ylab="Eixo y") #plot da fun��o
      abline(h=0, lty=2)
      abline(v=0, lty=2)

      points(m_k[1:cont], z_k[1:cont], col="blue", pch = 1) # Plot dos pontos m_k sobre o eixo x
      index <-c(0:cont)
      if(svalue(pont)){
        text(m_k[1:cont],z_k[1:cont],index,cex=0.65, pos=3, col="blue")
      }
      segments(a_k[1:cont],rep(0,cont),a_k[1:cont],fa_k[1:cont], col= "azure4", lty=2)
      if(svalue(linsc)){
        segments(a_k[1:cont],fa_k[1:cont],b_k[1:cont],fb_k[1:cont], col="yellow", lwd = 1.2)
      }

      #Resultados a serem mostrados ao usu�rio
      valuetextm <- paste("Aproxima��es: ",paste0(m_k, collapse =" | "))
      insert(mk_output,valuetextm)
    }

    #== Erro para caso tenha um n�mero par de ra�zes
    else{
      error.NoNegative <- gwindow("Erro",width = 10)
      error.NNgt <- ggroup(horizontal = FALSE, container = error.NoNegative)
      error.NNgb <- ggroup(horizontal = FALSE, container = error.NoNegative)
      error.NNlabel <- glabel("No intervalo dado a fun��o n�o tem raiz ou tem um n�mero par de ra�zes. Escolha outro interlavo", container=error.NNgt)
      exit.NN <-function(h,...){dispose(error.NoNegative)}
      gbutton("Ok", cont= error.NNgb, handler = exit.NN)

    }
  }


  #===========================================================================
  #INTERFACE
  winfalse <- gwindow("M�todo da Falsa Posi��o") #Janela Principal

  ##= Cria��o dos grupos
  Groupbuttons <- ggroup(container = winfalse, horizontal=FALSE)
  Groupgraphic <- ggroup(container = winfalse, horizontal=FALSE)

  ##= Cria��o dos frames
  buttonsFrame <- gframe("Dados de Entrada", container = Groupbuttons, horizontal = FALSE) #
  gbutton("Desenhe", cont= Groupbuttons, handler = falsa)
  valueframe <- gframe("Resultados", container = Groupbuttons, hozizontal = TRUE, expand = TRUE)
  mk_output <- gtext("", container=valueframe, expand = TRUE)

  ##= Cria��o das op��es graficas
  checkboxframe <- gframe("Op��es Gr�ficas", container =Groupgraphic, horizontal = TRUE)
  glabel("", container= checkboxframe)
  pont <- gcheckbox("�ndices das aproxima��es", checked = FALSE, cont =checkboxframe)
  linsc <- gcheckbox("Linha secante", checked = TRUE, cont= checkboxframe, expand = TRUE)

  ##= Cria��o da �rea do zoom
  zoomGraphFrame <- gframe("Zoom do gr�fico principal", container = Groupbuttons, horizontal = FALSE)
  gg2<-ggraphics(container = zoomGraphFrame,  width = 220, height = 220)

  ##= Cria��o da �rea do plot principal
  mainGrapghFrame <- gframe("Gr�fico Principal", container = Groupgraphic)
  gg<-ggraphics(container = mainGrapghFrame, width = 650, height = 650)

  ##= �rea de entrada dos dados
  functionframe <- gframe("Fun��o", container = buttonsFrame, horizontal = TRUE)
  env_function<-gedit("",width = 50, cont = functionframe, initial.msg = "ex: 2*x + exp(x) - sin(x) + log(x)", expand = TRUE)

  stopframe <- gframe("Precis�o desejada", container= buttonsFrame, horizontal=FALSE)
  tf1<-ggroup(container = stopframe, horizontal=TRUE )
  glabel("N�mero de casas decimais:", container = tf1)
  env_stop<-gedit("",width = 7, cont = tf1, initial.msg = "ex.: 2 para duas casas decimais", expand = TRUE)
  tf2<-ggroup(container = stopframe, horizontal=TRUE )
  glabel("N�mero m�ximo de itera��es:", container = tf2)
  env_inter<-gedit("",width = 7, cont = tf2, initial.msg = "Preenchimento n�o obrigat�rio", expand = TRUE)
  
  intervalframe <- gframe("Intervalo", container = buttonsFrame, horizontal = TRUE)
  glabel("Intervalo no eixo x:", container = intervalframe)
  env_pts<-gedit("", width = 21,cont = intervalframe, initial.msg = "Separados por espa�o", expand = TRUE)
  
  intervalplotframe <- gframe("Intervalo de Plot", container = buttonsFrame, horizontal = TRUE)
  glabel("No eixo x:", container = intervalplotframe)
  env_plotpts<-gedit("", width = 21,cont = intervalplotframe, initial.msg = "Separados por espa�o", expand = TRUE)

  sppedframe <- gframe("Velocidade da anima��o", container= buttonsFrame, horizontal=TRUE)
  glabel("Tempo em segundos:", container = sppedframe)
  env_speed<-gedit("",width = 35, cont = sppedframe, initial.msg = "Intervalo de tempo entre as itera��es", expand = TRUE)

  ##= Cria��o do bot�o de saida
  exit_func<-function(h,...){dispose(winfalse)}
  gbutton("SAIR", cont= Groupbuttons, handler = exit_func)

  ##= while utilizado na constru��o da anima��o
  while(isExtant(winfalse)){Sys.sleep(1)}

  ##= Mudar o �cone da janela
  # dir <- dirname(sys.frame(1)$ofile)
  # icon_dir <-paste0(dir, "/icon.png")
  # img <- gdkPixbufNewFromFile(icon_dir)
  # getToolkitWidget(winfalse)$setIcon(img$retval)


}
###########################################################################################
#' M�todo Newton-Rapson:
#' Ilustra as itera��es feitas pelo m�todo  Newton_Raphson, que obtem aproxima��es para as ra�zes de uma dada fun��o real.
#'
#' @param Funcao A equa��o que descreve a fun��o para a qual se deseja encontrar as ra�zes. Ex: exp(x) - x^2 + sqrt(x + 2)
#' @param Pto_inicial "Aproxima��o inicial"
#' @param Intervalo_x Define o intervalo no eixo x de visualiza��o da fun��o dada, separados por espa�o e na ordem crescente
#' @param N_Casas N�mero de casas decimais correspondente a precisao desejada
#' @param N_Iteracoes N�mero m�ximo de itera��es
#' @param Tempo Tempo de exibi��o de cada itera��o
#' @param OG_Indices Determina se os indices das aproxima��es obtidas em cada itera��o ser�o exibidos ou n�o
#' @param OG_Linha_Tangante Determina se as retas tangentes ao gr�fico, utilizadas pelo m�todo ser�o exibidas ou n�o
#' @param OG_Linha_vertical Determina se as linhas verticais ligando o ponto da fun��o no eixo x ser�o exibidas ou n�o
NEWTONRAPSON <-function()
{
  #== Mensagem inicial na �rea de resultados
  valuetextm <- "Aproxima��es obtidas"

  ##================================================================
  ##========== FUN��ES

  #==== Fun��o principal (que faz o m�todo)
  newtonraphson<- function(h,...)
  {
    #== Valores de entrada
    pointsentr<-svalue(env_pts)
    f<-svalue(env_function)
    x0<-as.numeric(svalue(env_x0))
    s<-as.numeric(svalue(env_stop))
    stp <- 10^(-s)
    stpint <- as.numeric(svalue(env_inter))
    if(is.na(stpint)) stpint <- 999 #n�mero ilimitado de itera��es
    speed<-as.numeric(svalue(env_speed))


    #=== pegar os valores separados em x
    #
    valxaux <- as.list(strsplit(pointsentr," ")[[1]])
    contval <- length(valxaux) # contador da quantidade de valores de entrada
    #intervalo
    a0 <-as.numeric(valxaux[1])
    b0 <- as.numeric(valxaux[2])


    # Criando strings de entrada
    func <- paste("func <- function(x){",f,"}")
    func2 <- paste("func2 <- expression(",f,")")

    # Transformando os textos salvos na variavel ftext em uma express�o
    eval(parse(text=func))
    eval(parse(text=func2))

    ##=== Criando a fun��o derivada primeira da fun��o de entrada
    DevFunc <- function(x){eval(D(func2,"x"))}
    f_x0 <- func(x0)     # valor da F(x0)
    Dev_x0 <-DevFunc(x0)   #valor da F'(x0)
    #Dev_x1 <- DevFunc((x0 - ((f_x0)/(Dev_x0))))  #valor da F'(x1)
    if(Dev_x0 == 0){ #= Erro caso a derivada fa fun��o em x0 seja zero
        #== Cria��o da janela de erro
        error.x0 <- gwindow("Erro")
        error.x0gt <- ggroup(horizontal = FALSE, container = error.x0)
        error.x0gb <- ggroup(horizontal = FALSE, container = error.x0)
        error.x0label <- glabel("a derivada da fun��o tem valor zero no ponto x0 dado como aproxima��o inicial", container=error.x0gt)
        exit.x0 <-function(h,...){dispose(error.x0)}
        gbutton("Ok", cont= error.x0gb, handler = exit.x0)
        stop
      }

    # Criando vetores para o plot
    x_k <- c()
    fx_k <- c()

    # Preenchendo os vetores
    x_k[1] <- x0
    x_k[2] <- x0 - f_x0/Dev_x0 #primeira itera��o para x1
    fx_k[1] <- f_x0
    fx_k[2] <- func(x_k[2]) #f(x1)

    # contador de �ndices para while
    cont <- 2

    #=== Garantindo que os pr�-requisitos est�o sendo seguidos exibindo janela de erro
    #
    if(abs(func(x0))<stp){ #= Erro caso o ponto dado j� satisfa�a o crit�rio de parada
      #== Cria��o da janela de erro
      error.x0 <- gwindow("Erro")
      error.x0gt <- ggroup(horizontal = FALSE, container = error.x0)
      error.x0gb <- ggroup(horizontal = FALSE, container = error.x0)
      error.x0label <- glabel("O ponto inicial dado j� satisfaz o crit�rio do erro m�nimo.", container=error.x0gt)
      exit.x0 <-function(h,...){dispose(error.x0)}
      gbutton("Ok", cont= error.x0gb, handler = exit.x0)
      stop #Parar o c�digo se a janela for criada
    }
    else{ #Continuar o c�digo...
      #===Come�o do m�todo em si
      whilevar <- -1
      while(whilevar == -1) #= fazer itera��es at� que o crit�rio seja atingido
      {
        cont <- cont + 1
        x_k[cont] <- (x_k[cont-1] - ((func(x_k[cont-1]))/(DevFunc(x_k[cont-1]))))
        fx_k[cont] <- func(x_k[cont])

        #Parar o m�todo pelo while
        if(cont>=stpint){whilevar <-1}
        if(abs(x_k[cont]-x_k[cont-1])<stp){whilevar <- 1}
        if(abs(fx_k[cont])<stp){whilevar <- 1}
      }
    }
    #==== Plot do m�todo
    #

    visible(gg) <- TRUE #= �rea grafica gg recebe o plot
    plot(func, xlim = c(a0, b0), col = "red", xlab="Eixo x", ylab="Eixo y") #= plot da curva
    abline(h=0, lty=2)
    abline(v=0, lty=2)
    z_k <- rep(0, cont) ## Vetor de zeros do tamanho do vetor m_k

    #== Anima��o
    #
    for (i in 1:cont) #Para cada itera��o
    {
      ##Plot dos pontos
      Sys.sleep(speed/4)
      points(x_k[1:i], z_k[1:i], col="blue", pch = 1) # Plot dos pontos x_k sobre o eixo x
      index <-c(0:(cont-1))

      if(svalue(pont)){ #Caso seja marcado os indicies dos pontos no checkbox
        text(x_k[i],z_k[i],  index[i], cex=0.65, pos=3, col="blue")
      }
      if(svalue(linvt)){ #Caso seja marcado as linhas verticais no checkbox
        Sys.sleep(speed/4)
        segments(x_k[i],0,x_k[i],fx_k[i], col= "azure4", lty=2)
      }
      ##Plot dos x_k na fun��o
      Sys.sleep(speed/4)
      points(x_k[1:i],fx_k[1:i], col="green", pch=1)
      if(svalue(lintg)){ #Caso seja marcado as linhas tangentes no checkbox
        Sys.sleep(speed/4)
        segments( x_k[i],fx_k[i],x_k[i+1],0,col = "black")
      }
    }

    #=== Plot do zoom
    #
    dx <- (b0-a0)/10
    visible(gg2) <- TRUE #agora a �rea grafica gg2 que ir� receber o plot
    par(mar=rep(0, 4)) #margem
    plot(func, xlim=c(x_k[cont] - dx,x_k[cont] + dx), col = "red", xlab="Eixo x", ylab="Eixo y") #plot da fun��o
    abline(h=0, lty=2)
    abline(v=0, lty=2)

    points(x_k[1:cont], z_k[1:cont], col="blue", pch = 1) # Plot dos pontos m_k sobre o eixo x
    index <-c(0:cont)
    if(svalue(pont)){
      text(x_k[1:cont],z_k[1:cont],index,cex=0.65, pos=3, col="blue")
    }

   # if(svalue(lintg)){ #Caso seja marcado as linhas tangente no checkbox

    #  for(i in 1:cont-1)
     #   segments(x_k[i],fx_k[i],x_k[i+1],0.0,col = "black")
    #}
    #if(svalue(linvt)){ #Caso seja marcado as linhas verticais no checkbox
      #while(i<cont){
     # for(i in 1:cont-1)
      #  segments(x_k[i],0.0,x_k[i],fx_k[i], col= "azure4", lty=2)
    #}
    #Resultados a serem mostrados ao usu�rio
    valuetextm <- paste("Aproxima��es: ",paste0(x_k, collapse =" | "))
    insert(xk_output,valuetextm)
  }

  #===========================================================================
  #INTERFACE
  winnewton <- gwindow("M�todo de Newton-Raphson") #Cria��o da janela

  ##= Cria��o dos grupos
  Groupbuttons <- ggroup(container = winnewton, horizontal=FALSE)
  Groupgraphic <- ggroup(container = winnewton, horizontal=FALSE)

  ##= Cria��o dos frames
  buttonsFrame <- gframe("Dados de Entrada", container = Groupbuttons, horizontal = FALSE)
  gbutton("Desenhe", cont= Groupbuttons, handler = newtonraphson)
  valueframe <- gframe("Resultados", container = Groupbuttons, hozizontal = TRUE, expand = TRUE)
  xk_output <- gtext("", container=valueframe, expand = TRUE)

  ##= Cria��o das op��es graficas
  checkboxframe <- gframe("Op��es gr�ficas", container =Groupgraphic, horizontal = TRUE)
  pont <- gcheckbox("�ndices dos pontos", checked = FALSE, cont =checkboxframe)
  lintg <- gcheckbox("Linhas tangentes", checked = TRUE, cont = checkboxframe)
  linvt <- gcheckbox("Linhas verticais", checked = TRUE, cont= checkboxframe)

  ##= Cria��o das �rea do zoom
  zoomGraphFrame <- gframe("Zoom do gr�fico principal", container = Groupbuttons, horizontal = FALSE)
  gg2<-ggraphics(container = zoomGraphFrame,  width = 220, height = 220)

  ##= Cria��o da �rea do plot principal
  mainGrapghFrame <- gframe("Gr�fico Principal", container = Groupgraphic)
  gg<-ggraphics(container = mainGrapghFrame, width = 650, height = 650)

  ##= �rea de entrada dos dados
  functionframe <- gframe("Fun��o", container = buttonsFrame, horizontal = TRUE)
  env_function<-gedit("",width = 50, cont = functionframe, initial.msg = "ex: 2*x + exp(x) - sin(x) + log(x)",  expand = TRUE)

  intervalframe <- gframe("Aproxima��o inicial", container = buttonsFrame, horizontal = TRUE)
  glabel("Ponto de inicio:", container = intervalframe)
  env_x0<-gedit("", width = 14,cont = intervalframe, initial.msg = "x0",  expand = TRUE)

  interframe <- gframe("Intervalo do plot", container = buttonsFrame, horizontal = TRUE)
  glabel("Intervalo no eixo x:", container = interframe)
  env_pts<-gedit("", width = 14,cont = interframe, initial.msg = "Separado por espa�o",  expand = TRUE)


  stopframe <- gframe("Precis�o desejada", container= buttonsFrame, horizontal=FALSE)
  tf1<-ggroup(container = stopframe, horizontal=TRUE )
  glabel("N�mero de casas decimais:", container = tf1)
  env_stop<-gedit("", cont = tf1, initial.msg = "ex.: 2 para duas casas decimais", expand = TRUE)
  tf2<-ggroup(container = stopframe, horizontal=TRUE )
  glabel("N�mero m�ximo de itera��es:", container = tf2)
  env_inter<-gedit("", cont = tf2, initial.msg = "Preenchimento n�o obrigat�rio", expand = TRUE)

  speedframe <- gframe("Velocidade da anima��o", container= buttonsFrame, horizontal=TRUE)
  glabel("Tempo em segundos:", container = speedframe)
  env_speed<-gedit("",width = 35, cont = speedframe, initial.msg = "Intervalo de tempo entre as itera��es",  expand = TRUE)

  ##= Bot�o de saida
  exit_func<-function(h,...){dispose(winnewton)}
  gbutton("SAIR", cont= Groupbuttons, handler = exit_func)

  ##= while utilizado na constru��o da anima��o
  while(isExtant(winnewton)) Sys.sleep(1)

  ##= Mudar o �cone da janela
#  dir <- dirname(sys.frame(1)$ofile)
#  icon_dir <-paste0(dir, "/icon.png")
#  img <- gdkPixbufNewFromFile(icon_dir)
#  getToolkitWidget(winbissection)$setIcon(img$retval)

}
###########################################################################################
#' Aproxima��o pelo m�todo das secantes:
#' Ilustra as itera��es feitas pelo m�todo da Secante, que obtem aproxima��es para as ra�zes de uma dada fun��o real.
#' @param Funcao A equa��o que descreve a fun��o para a qual se deseja encontrar as ra�zes. Ex: exp(x) - x^2 + sqrt(x + 2)
#' @param Intervalo_x Intervalo contento a raiz da fun��o, separado por espa�o, exemplo: -5 6
#' @param N_Casas N�mero de casas decimais correspondente � precisao desejada
#' @param N_Iteracoes Define o N�mero m�ximo de itera��o, 0 (zero) para limitar apenas pelas casas decimais
#' @param Tempo Tempo de exibi��o de cada itera��o
#' @param OG_Indices Determina se os �ndices das aproxima��es obtidas em cada itera��o ser�o exibidos ou n�o
#' @param OG_Linha_secante  Determina se as retas secantes ao gr�fico, utilizadas pelo m�todo ser�o exibidas ou n�o
#' @param OG_Linha_vertical Determina se as linhas verticais ligando o ponto da fun��o no eixo x ser�o exibidas ou n�o
SECANTE <-function()
{
  #== Mensagem inicial na �rea de resultados
  valuetextm <- "Aproxima��es obtidas"

  ##================================================================
  ##========== FUN��ES


  #==== Fun��o principal (que faz o m�todo)
  secante<- function(h,...) #Fun??o principal (que faz o m�todo)
  {
    #== Valores de entrada
    f<-svalue(env_function)
    pointsentr<-svalue(env_pts)
    initical_point <-svalue(env_init)
    speed<-as.numeric(svalue(env_speed))

    stpcont <-as.numeric(svalue(env_stpcont))
    if(is.na(stpcont)){stpcont<-9999}

    s<-as.numeric(svalue(env_stop))
    stp <- 10^(-s)


    #=== pegar os valores separados em x
    #
    valxaux <- as.list(strsplit(pointsentr," ")[[1]])
    contval <- length(valxaux) # contador da quantidade de valores de entrada
    #intervalo
    a0 <-as.numeric(valxaux[1])
    b0 <- as.numeric(valxaux[2])

    valxaux <- as.list(strsplit(initical_point," ")[[1]])
    contval <- length(valxaux) # contador da quantidade de valores de entrada

    x0 <-as.numeric(valxaux[1])
    x1 <- as.numeric(valxaux[2])



    func <- paste("func <- function(x){",f,"}") # Criando string de entrada
    eval(parse(text=func))# Transformando o texto salvo na variavel ftext em uma expressao

    f_x0 <- func(x0)
    f_x1 <- func(x1)

    # Criando vetores para o plot
    x_k <- c()
    fx_k <- c()

    #Preenchendo os vetores
    x_k[1] <- x0
    x_k[2] <- x1
    fx_k[1] <- f_x0
    fx_k[2] <- f_x1

    # contador de �ndices para while
    cont <- 2


    whileaux <- -1 #teste para fazer ate chegar ao erro desejado

 #   if(((f_x0)*(f_x1))>0){ # Erro para garantir que os extremos tem sinais diferentes
      #== Cria��o da janela de erro
  #    error.x0 <- gwindow("Erro", height=100, parent=c(250,100))
  #    error.x0gt <- ggroup(horizontal = FALSE, container = error.x0)
  #    error.x0label <- glabel("O intervalo ou n�o tem raiz ou tem um n�mero par de ra�zes [ f(a)*f(b)<0 ]
                        #      por favor, selecione um intervalo melhor.", container=error.x0gt)
   #   exit.x0 <-function(h,...){dispose(error.x0)}
   #   gbutton("Ok", cont= error.x0gt, handler = exit.x0)
   # }

    #===Come�o do m�todo em si
    #
    #else{
      while(whileaux == -1) # Garantir que seja at� o crit�rio ser atingido
      {
        cont <- cont + 1
        x_k[cont] <- (x_k[cont-1] - ((fx_k[cont-1])*((x_k[cont-1] - x_k[cont-2])/(fx_k[cont-1] - fx_k[cont-2]))))
        fx_k[cont] <- func(x_k[cont])

        Errosec <-((x_k[cont]-x_k[cont-1])/(x_k[cont]))
        ##= Mudar o test quando atingir o erro desejado
        if(abs(Errosec)<stp){whileaux <- 1}
        if(cont>stpcont){whileaux <- 1}
        if(abs(fx_k[cont])<stp){whileaux <- 1}
      }

      #==== Plot do m�todo

      visible(gg) <- TRUE #Agora a �rea grafica gg que ir� receber o plot

      plot(func,xlim = c(a0, b0), col = "red", xlab="Eixo x", ylab="Eixo y") #= plot da curva
      abline(h=0, lty=2)
      abline(v=0, lty=2)

      z_k <- rep(0, cont) #= vetor de zeros

      #== Anima��o
      #
      index <-c(0:(cont-1)) #indices
      if(svalue(pont))
      text(x_k[1],z_k[1],  index[1], cex=0.65, pos=3, col="blue")
      points(x_k[1], z_k[1], col="blue", pch = 1) # Plot dos pontos x_k sobre o eixo x

      Sys.sleep(speed/4)
      if(svalue(linvt)) #linhas verticais
      segments(x_k[1],0,x_k[1],fx_k[1], col= "azure4", lty=2)
      Sys.sleep(speed/4)
      points(x_k[1],fx_k[1], col="green", pch=1) #Plot dos x_k na fun��o

      for (i in 2:(cont))
      {
        Sys.sleep(speed/4)
        points(x_k[1:i], z_k[1:i], col="blue", pch = 1) # Plot dos pontos x_k sobre o eixo x

        if(svalue(linvt)){ #linhas verticais
          Sys.sleep(speed/4)
          segments(x_k[i],0,x_k[i],fx_k[i], col= "azure4", lty=2)
        }

        Sys.sleep(speed/4)
        points(x_k[2:i],fx_k[2:i], col="green", pch=1) #Plot dos x_k na fun��o

        Sys.sleep(speed/4)
        if(svalue(pont)){ #indices dos pontos
          text(x_k[i],z_k[i],  index[i], cex=0.65, pos=3, col="blue")
        }

        if(svalue(linsc)){ #linhas secantes
          Sys.sleep(speed/4)
           if((fx_k[i-1]*fx_k[i])<0)
              segments(x_k[i-1],fx_k[i-1],x_k[i],fx_k[i],col = "yellow")
            else
              segments(x_k[i-1],fx_k[i-1],x_k[i+1],0.0,col="yellow")
        }
      }


      #=== Plot do zoom
      dx <- (b0-a0)/10
      visible(gg2) <- TRUE #agora a �rea grafica gg2 que ir� receber o plot
      par(mar=rep(0, 4)) #margem
      plot(func, xlim=c(x_k[cont]-dx, x_k[cont]+dx), col = "red", xlab="", ylab="") #plot da fun��o
      abline(h=0, lty=2)
      abline(v=0, lty=2)

      points(x_k[1:cont], z_k[1:cont], col="blue", pch = 1) # Plot dos pontos m_k sobre o eixo x

      if(svalue(pont)){ #Caso seja marcado os pontos no checkbox
        text(x_k,z_k,  index, cex=0.65, pos=3, col="blue")
      }
      if(svalue(linsc)){ #Caso seja marcado as linhas tangente no checkbox
        for(i in (1:cont)){
          if(i<cont){
            if((fx_k[i]*fx_k[i+1])<0){
              segments(x_k[i],fx_k[i],x_k[i+1],fx_k[i+1],col = "yellow")
            }
            else{
              segments(x_k[i],fx_k[i],x_k[i+2],0,col="yellow")
            }
          }
        }
      }

      if(svalue(linvt)){ #linhas verticais
        for(i in 1:cont){
          segments(x_k[i],0,x_k[i],fx_k[i], col= "azure4", lty=2)
        }
      }

      #Resultados a serem mostrados ao usu�rio
      valuetextm <- paste("Aproxima��es: ",paste0(x_k, collapse =" | "))
      insert(xk_output,valuetextm)



  }

  #===========================================================================
  #INTERFACE
  winsecante <- gwindow("M�todo da Secante") #= janela principal

  ##= Cria��o dos grupos
  Groupbuttons <- ggroup(container = winsecante, horizontal=FALSE)
  Groupgraphic <- ggroup(container = winsecante, horizontal=FALSE)

  ##= Cri��o dos frames
  buttonsFrame <- gframe("Dados de Entrada", container = Groupbuttons, horizontal = FALSE)
  gbutton("Desenhe", cont= Groupbuttons, handler = secante)
  valueframe <- gframe("Resultados", container = Groupbuttons, hozizontal = TRUE, expand = TRUE)
  xk_output <- gtext("", container=valueframe, expand = TRUE)

  ##= Cria��o das op��es gr�ficas
  checkboxframe <- gframe("Op��es", container =Groupgraphic, horizontal = TRUE)
  glabel("Selecione antes do Plot", container= checkboxframe)
  pont <- gcheckbox("�ndices de x", checked = FALSE, cont =checkboxframe)
  linsc <- gcheckbox("Linhas Secantes", checked = TRUE, cont = checkboxframe)
  linvt <- gcheckbox("Linhas verticais", checked = TRUE, cont= checkboxframe)

  ##= Cria��o das �rea do zoom
  zoomGraphFrame <- gframe("Zoom do gr�fico principal", container = Groupbuttons, horizontal = FALSE)
  gg2<-ggraphics(container = zoomGraphFrame,  width = 220, height = 220)

  ##= Cria��o da �rea do plot principal
  mainGrapghFrame <- gframe("Grafico Principal", container = Groupgraphic)
  gg<-ggraphics(container = mainGrapghFrame, width = 650, height = 650)

  ##= �rea de entrada dos dados
  functionframe <- gframe("Fun��o", container = buttonsFrame, horizontal = TRUE)
  env_function<-gedit("",width = 50, cont = functionframe, initial.msg = "ex: 2*x + exp(x) - sin(x) + log(x)", expand = TRUE)

  intervalframe <- gframe("Aproxima��es Iniciais", container = buttonsFrame, horizontal = TRUE)
  glabel("x0 e x1:", container = intervalframe)
  env_init<-gedit("", width = 14,cont = intervalframe, initial.msg = "Separados por espa�o", expand = TRUE)

  intervalframe <- gframe("Intervalo", container = buttonsFrame, horizontal = TRUE)
  glabel("Intervalo no eixo x:", container = intervalframe)
  env_pts<-gedit("", width = 14,cont = intervalframe, initial.msg = "Separados por espa�o", expand = TRUE)
  
  stopframe <- gframe("Precis�o desejada", container= buttonsFrame, horizontal=FALSE)
  tf1<-ggroup(container = stopframe, horizontal=TRUE )
  glabel("N�mero de casas decimais:", container = tf1)
  env_stop<-gedit("", cont = tf1, initial.msg = "ex.: 2 para duas casas decimais", expand = TRUE)
  tf2<-ggroup(container = stopframe, horizontal=TRUE )
  glabel("N�mero m�ximo de itera��es:", container = tf2)
  env_stpcont<-gedit("", cont = tf2, initial.msg = "Preenchimento n�o obrigat�rio", expand = TRUE)

  speedframe <- gframe("Velocidade da anima��o", container= buttonsFrame, horizontal=TRUE)
  glabel("Tempo em segundos:", container = speedframe)
  env_speed<-gedit("",width = 35, cont = speedframe, initial.msg = "Intervalo de tempo entre as itera��es", expand = TRUE)

  ##= cria��o do botao de saida
  exit_func<-function(h,...){dispose(winsecante)}
  gbutton("SAIR", cont= Groupbuttons, handler = exit_func)

  ##= while utilizado na constru��o da anima��o
  while(isExtant(winsecante)) Sys.sleep(1)

  ##= Mudar o icone da janela
 # dir <- dirname(sys.frame(1)$ofile)
 # icon_dir <-paste0(dir, "/icon.png")
 # img <- gdkPixbufNewFromFile(icon_dir)
 # getToolkitWidget(winsecante)$setIcon(img$retval)
}
##########################################################################################

############################################################################################
#' M�todo dos Trap�zios:
#' Ilustra as itera��es feitas pelo m�todo dos trap�zios, m�todo que aproxima o valor da integral de uma fun��o em um dado intervalo.
#'
#' @param Funcao A equa��o que descreve a fun��o para a qual se deseja calcular a integral
#' @param Intervalo Intervalo onde ser� feita a aproxima��o da integral, separado por espa�o, exemplo: -3 9.87
#' @param Numero_de_Intervalos Define em quantas vezes o intervalo dado ser� dividido
#' @param Tempo Regula quanto tempo durar� cada itera��o
#' @param OG_Indices Determina se os �ndices dos pontos ser�o exibidos
#' @param OG_Pintar_Area Determina se a �rea abaixo das linhas formadas pelo m�todo devem ser pintadas ou n�o
#' @param OG_Linhas_Verticais Determina se ser�o plotadas as linhas verticais associados a cada ponto
TRAPEZIOS <-function()
{
  #== Mensagem inicial na �rea de resultados
  valuetextm <- "Aproxima��es obtidas"

  ##================================================================
  ##========== FUN��ES


  #==== Fun��o principal (que faz o m�todo)
  integral<- function(h,...)
  {
    #== Valores de entrada
    f<-svalue(env_function)
    interentr<-svalue(env_entr)
    div<-as.numeric(svalue(env_div))
    speed<-as.numeric(svalue(env_speed))

    #============== pegar os valores separados em x =======
    interaux <- as.list(strsplit(interentr," ")[[1]]) # contador da quantidade de valores de entrada, serve tanto para o x quanto para y
    limitx <- c()
    for(i in 1:2){
      limitx[i] <- as.numeric(interaux[i])
    }

    #criando uma nova string: func <- function(x){ string da entrada}
    func <- paste("func <- function(x){",f,"}")
    func2 <- paste("func2 <- expression(",f,")")

    # transformando o texto salvo na vari�vel ftext em uma express�o
    eval(parse(text=func))
    eval(parse(text=func2))

    ##== Fun��es derivadas
    DevFunc2 <- function(x){eval(D(D(func2,"x"),"x"))}
    DevFunc3 <- function(x){eval(D(D(D(func2,"x"),"x"),"x"))}

    #=== fun��o com o calculo da soma do m�todo
    trapezoid <- function(fun, a, b, n) {
      h <- (b-a)/n
      x <- seq(a, b, by=h)
      y <- func(x)
      s <- h * (y[1]/2 + sum(y[2:n]) + y[n+1]/2)
      return(s)
    }

    ##= Vari�vel com a soma do m�todo
    soma <- abs(trapezoid(func, limitx[1], limitx[2], div + 1))

    ##= Vetores com os valores de x
    pointx <- c()
    pointy <- c()
    pointx[1] <- limitx[1]
    pointy[1] <- func(pointx[1])
    h <- ((limitx[2] - limitx[1])/div)
    for(i in 2:(div+1)){
      pointx[i] <- (pointx[i-1] + h)
      pointy[i] <- func(pointx[i])
    }

    ##= limites do plot
    xmin <- limitx[1]
    xmax <- limitx[2]

    ##=== C�lculo do erro
    #

    #= Achar os pontos cr�ticos
    j<- 1
    crit <- c()
    for(i in seq(from=xmin, to=xmax, by=0.01)){
      if(((DevFunc3(i))>-0.1)&&(DevFunc3(i)<0.1)){
        crit[j] <- DevFunc2(i)
        j <- j + 1
      }
    }

    #= Calcular a derivada segunda dos extremos e seu maior valor de todas as derivadas segundas
    #
    Dev2min <- DevFunc2(xmin)
    Dev2max <- DevFunc2(xmax)

    if(Dev2min>Dev2max){
      valmax <- Dev2min
    }
    else {
      valmax <-Dev2max
    }
    if(j>1){
      for(i in 1:(j-1)){
        if(valmax < crit[i]){
          valmax <- crit[i]
        }
      }
    }

    ##= C�lculo do erro
    Errotrap <- valmax*(((xmax-xmin)*(h^2))/(12))

    #vetor de zeros para o plot
    z_k <- rep(0, (div+1))

    #==== Plot do m�todo
    #
    visible(gg) <- TRUE #a �rea grafica gg que passar� a receber os plots
    plot(func, xlim=c(xmin, xmax), col = "red", xlab="Eixo x", ylab="Eixo y")#Plot da f(x)
    abline(h=0, lty=2)
    abline(v=0, lty=2)

    #anima��o
    Sys.sleep(speed/4)

    points(pointx, pointy, col="blue", pch = 1) # Plot dos pontos x e f_x
    index <-c(0:(div)) #vetor com os indices para o plot

    if(svalue(pont)){ #Caso seja marcado os �ndices dos pontos no checkbox
      text(pointx,pointy,  index, cex=0.65, pos=3, col="blue")
    }
    if(svalue(linvt)){ #Caso seja marcado as retas verticais no checkbox
      segments(pointx, z_k, pointx, pointy, lty=2 , col = "gray48")
    }

    for (i in 1:(div+1)) #fazer as retas dos trapezios
    {
      Sys.sleep(speed/4)
      if(i!=(div+1)){  #If para que i chegue apenas at� div e n�o quebre o codigo
        segments(pointx[i],pointy[i],pointx[i+1],pointy[i+1])
      }
    }


    #========= Pintar a �rea ==============
    if(svalue(pint)){
      for(i in 1:div){
        xini <- pointx[i] #=== x inicial
        xfin <- pointx[i+1] #==== x final
        cord.x <- c(xini,xini,xfin,xfin)
        cord.y <- c(0,pointy[i],pointy[i+1],0)
        polygon(cord.x,cord.y, col="skyblue", border = "skyblue")
      }

      for (i in 1:(div+1))
      {
        if(i!=(div+1)){  #If para que i chegue apenas at� div e n�o quebre o codigo
          segments(pointx[i],pointy[i],pointx[i+1],pointy[i+1])
        }
      }

      if(svalue(linvt)){
        segments(pointx, z_k, pointx, pointy, lty=2 , col = "gray48")
      }
      
      curve(func, col = "red",lwd=2, add=TRUE)
      
      #Resultados a serem mostrados ao usu�rio
      valuetextm <- paste0("\n valor da soma pelo m�todo: ",soma,"\n", "O erro do m�todo: ",Errotrap)
      dispose(xk_output)
      insert(xk_output,valuetextm)

    }
  }

  #===========================================================================
  #INTERFACE
  wintrapezio <- gwindow("M�todo dos Trapezios") #Cria��o da janela

  ##= Cria��o dos grupos
  Groupbuttons <- ggroup(container = wintrapezio, horizontal=FALSE)
  Groupgraphic <- ggroup(container = wintrapezio, horizontal=FALSE)

  ##= Cria��o dos frames
  buttonsFrame <- gframe("Dados de Entrada", container = Groupbuttons, horizontal = FALSE)
  gbutton("Desenhe", cont= Groupbuttons, handler = integral)
  valueframe <- gframe("Resultados", container = Groupbuttons, hozizontal = TRUE, expand = TRUE)
  xk_output <- gtext("", container=valueframe, expand = TRUE, width = 300)

  ##= Cria��o das op��es gr�ficas
  checkboxframe <- gframe("Op��es", container =Groupgraphic, horizontal = TRUE)
  glabel("Selecione antes do Plot", container= checkboxframe)
  pont <- gcheckbox("�ndices de x", checked = FALSE, cont =checkboxframe)
  pint <- gcheckbox("Pintar �rea", checked = TRUE, cont = checkboxframe)
  linvt <- gcheckbox("Linhas verticais", checked = TRUE, cont= checkboxframe)

  ##= Cria��o da �rea do plot principal
  mainGrapghFrame <- gframe("Gr�fico Principal", container = Groupgraphic)
  gg<-ggraphics(container = mainGrapghFrame, width = 650,height = 650)

  ##= �rea de entrada dos dados
  functionframe <- gframe("Fun��o", container = buttonsFrame, horizontal = TRUE)
  env_function<-gedit("", cont = functionframe, initial.msg = "ex: 2*x + exp(x) - sin(x) + log(x)", expand = TRUE)

  intervalframe <- gframe("Intervalo", container = buttonsFrame, horizontal = TRUE)
  glabel("Intervalo no eixo x:", container = intervalframe)
  env_entr<-gedit("",cont = intervalframe, initial.msg = "ex.: -2 3", expand = TRUE)

  stopframe <- gframe("Divis�es", container= buttonsFrame, horizontal=TRUE)
  glabel("N�mero de subintervalos:", container = stopframe)
  env_div<-gedit("", cont = stopframe, initial.msg = "ex.: 5", expand = TRUE)

  speedframe <- gframe("Velocidade da anima��o", container= buttonsFrame, horizontal=TRUE)
  glabel("Tempo em segundos:", container = speedframe)
  env_speed<-gedit("", cont = speedframe, initial.msg = "Intervalo de tempo entre as itera��es", expand = TRUE)

  ##= cria��o do botao de saida
  exit_func<-function(h,...){dispose(wintrapezio)}
  gbutton("SAIR", cont= Groupbuttons, handler = exit_func)

  ##= while utilizado na constru��o da anima��o
  while(isExtant(wintrapezio)) Sys.sleep(1)

  ##= Mudar o icone da janela
 # dir <- dirname(sys.frame(1)$ofile)
  #icon_dir <-paste0(dir, "/icon.png")
 # img <- gdkPixbufNewFromFile(icon_dir)
 # getToolkitWidget(winbissection)$setIcon(img$retval)
}
###########################################################################################
#' M�todo de Simpson:
#' Ilustra as itera��es feitas pelo m�todo dos Simpson, que aproxima o valor da integral de uma fun��o em um dado intervalo.
#'
#' @param Funcao A equa��o que descreve a fun��o para a qual se deseja calcular a integral
#' @param Intervalo Intervalo onde sera feita a aproxima��o da integral, separado por espa�o, exemplo: -3 9
#' @param Numero_de_Intervalos Define em quantas vezes o intervalo dado sera dividido
#' @param Tempo Regula quanto tempo durara cada itera��o
#' @param OG_Indices Determina se os �ndices dos pontos ser�o exibidos
#' @param OG_Pintar_Area Determina se a �rea abaixo das curvas formadas pelo m�todo devem ser pintadas ou n�o
#' @param OG_Linhas_Verticais Determina se ser�o plotadas as linhas verticais associados a cada ponto
SIMPSON <-function()
{
  #== Mensagem inicial na �rea de resultados
  valuetextm <- "Aproxima��es obtidas"

  ##================================================================
  ##========== FUN��ES

  #==== Fun��o principal (que faz o m�todo)
  integral<- function(h,...)
  {
    #== Valores de entrada
    f<-svalue(env_function)
    interentr<-svalue(env_entr)
    div<-as.numeric(svalue(env_div))
    speed<-as.numeric(svalue(env_speed))

    #============== pegar os valores separados em x =======
    interaux <- as.list(strsplit(interentr," ")[[1]])
    limitx <- c()
    for(i in 1:2){
      limitx[i] <- as.numeric(interaux[i])
    }

    # Criando strings de entrada
    func <- paste("func <- function(x){",f,"}")
    func2 <- paste("func2 <- expression(",f,")")

    # transformando o texto salvo em uma express?es
    eval(parse(text=func))
    eval(parse(text=func2))

    #=============== Fun��es derivadas ===============
    DevFunc4 <- function(x){eval(D(D(D(D(func2,"x"),"x"),"x"),"x"))}
    DevFunc5 <- function(x){eval(D(D(D(D(D(func2,"x"),"x"),"x"),"x"),"x"))}

    # Vetores para o plot
    pointx <- c()
    pointy <- c()


    if((div%%2)!=0) # Erro para caso o n�mero de intervalos seja �mpar
    {
      error.INTERIMP <- gwindow("Erro", width = 15)
      error.IIgt <- ggroup(horizontal = FALSE, container = error.INTERIMP)
      error.IIgb <- ggroup(horizontal = FALSE, container = error.INTERIMP)
      error.FAlabel <- glabel("O n�mero de subintervalos � impar, favor forneca um n�mero par de subintervalos.", container=error.IIgt)
      exit.II <-function(h,...){dispose(error.INTERIMP)}
      gbutton("Ok", cont= error.IIgb, handler = exit.II)
      stop
    }

    else{
      #===Comeco do m�todo em si
      #
      simpson <- function(fun, a, b, n) {
        h <- (b-a)/n
        x <- seq(a, b, by=h)
        y <- fun(x)
        s <- (h/3) * ( y[1] + y[n] + 4*(sum(y[2*(1:(n/2))+1])) + 2*(sum(y[2*(1:((n/2)-1))])) )
        return(s)
      }

      soma <- simpson(func, limitx[1], limitx[2], div)

      # ====Preenchendo os vetores para o plot
      pointx[1] <- limitx[1]
      pointy[1] <- func(pointx[1])
      h <- ((limitx[2] - limitx[1])/div)
      for(i in 2:(div+1)){
        pointx[i] <- (pointx[i-1] + h)
        pointy[i] <- func(pointx[i])
      }

      ##=== Plotar a fun��o dentro do intervalo

      xmin <- limitx[1]
      xmax <- limitx[2]

      ##======== Calcular o erro ======
      ##
      j<- 1 #j � uma variavel para encher o vetor critico
      crit <- c() #=== que ser� preenchido
      for(i in seq(from=xmin, to=xmax, by=0.01)){ ##=== Achar todos os pontos cr�ticos
        if(((DevFunc5(i))>-0.1)&&(DevFunc5(i)<0.1)){
          crit[j] <- DevFunc4(i)  #=== Encher o vetor crit quando encontrado
          j <- j + 1
        }
      }

      Dev4min <- DevFunc4(xmin) #Valor da f''(x) quando xmin
      Dev4max <- DevFunc4(xmax) #Valor da f''(x) quando xmax

      if(Dev4min>Dev4max){ #Achar qual � maior dos valores da f''(x) nos extremos
        valmax <- Dev4min
      }
      else {   #Achar qual � maior dos valores da f''(x) nos extremos
        valmax <-Dev4max
      }
      if(j>1){
        for(i in 1:(j-1)){ #Avaliar entre o valor dos extremos e os criticos da f''(x)
          if(valmax < crit[i]){
            valmax <- crit[i]
          }
        }
      }
      Errosimp<- - valmax*(((xmax-xmin)*(h^4))/(180)) #Erro propriamente

      #==== Plot do m�todo
      #
      visible(gg) <- TRUE
      plot(func, xlim=c(xmin,xmax), col = "red", xlab="eixo x", ylab="eixo y")
      abline(h=0, lty=2)
      abline(v=0, lty=2)

      z_k <- rep(0, (div+1)) #Vetor de zeros
      index <-c(0:(div-1)) #Indice

      for (i in 1:(div+1))
      {

        if(svalue(linvt)){
          segments(pointx[i], z_k[i], pointx[i], pointy[i], lty=2 , col = "azure3")
        }
        points(pointx[i], pointy[i], col="blue", pch = 1) # Plot dos pontos x e f_x
        index <-c(0:(div))

        if(svalue(pont)){ #Caso seja marcado os indicies dos pontos no checkbox
          text(pointx[i],pointy[i],  index[i], cex=0.65, pos=3, col="blue")
        }
      }
      #Vetor para o plot das par�bolas
      Fpoli<- c()

      #============== Plot das parabolas ================#
      for(i in seq(from=1, to=(div-1), by=2)){
        Sys.sleep(speed)
        Amatr <- array(c((pointx[i])^2,(pointx[i+1])^2,(pointx[i+2])^2,pointx[i],pointx[i+1],pointx[i+2],1,1,1),c(3,3))#Matriz com pontos
        Ypon <- c(pointy[i],pointy[i+1],pointy[i+2]) #=== Vetor com os valores em y
        Ainver <- solve(Amatr) #=== Matriz inversa para resolu��o
        ABCMatr <- Ainver %*% Ypon #=== matriz com os valores A, B e C, do polin�mio que esta sendo feito
        Fpoli[i] <- paste0(ABCMatr[1],"*x^2+",ABCMatr[2],"*x+",ABCMatr[3]) #==== Juntando o valor da matriz inversa com o A B e C
        polifun <- paste("polifun <- function(x){",Fpoli[i],"}")
        eval(parse(text=polifun))
        curve(polifun , (pointx[i]-h*0.15), (pointx[i+2]+h*0.15),type="l", add=TRUE)
      }

      #========= Pintar a �rea ============#
      if(svalue(pint)){
        Sys.sleep(speed)
        for(i in seq(from=1, to=(div-1), by=2)){
          polifun <- paste("polifun <- function(x){",Fpoli[i],"}")
          eval(parse(text=polifun))
          xini <- pointx[i] #=== x inicial ===
          xfin <- pointx[i+2] #==== x final
          cord.x <- c(xini,seq(xini,xfin,0.01),xfin)
          cord.y <- c(0,polifun(seq(xini,xfin,0.01)),0)
          polygon(cord.x,cord.y, col="skyblue", border = "skyblue")
          curve(polifun , (pointx[i]-h*0.15), (pointx[i+2]+h*0.15),type="l", add=TRUE)
        }
      }

      #Plot da fun��o de novo, para ficar a cima dos outros plots
      curve(func, xmin -1, xmax +1, col = "red", xlab="eixo x", ylab="eixo y", lwd=2, add=TRUE)
      abline(h=0, lty=2)
      for (i in 1:(div+1))
      {
        
        if(svalue(linvt)){
          segments(pointx[i], z_k[i], pointx[i], pointy[i], lty=2 , col = "azure3")
        }
        points(pointx[i], pointy[i], col="blue", pch = 1) # Plot dos pontos x e f_x
        index <-c(0:(div))
        
        if(svalue(pont)){ #Caso seja marcado os indicies dos pontos no checkbox
          text(pointx[i],pointy[i],  index[i], cex=0.65, pos=3, col="blue")
        }
      }

      #Resultados a serem mostrados ao usu�rio
      valuetextm <- paste0("Resultado obtido pelo m�todo:",soma,"\n","Limitante para o erro obtido", Errosimp,"\n")
      insert(xk_output,valuetextm)

    }
  }

  #===========================================================================
  #INTERFACE
  winsimpson <- gwindow("M�todo de Simpson") #Cria��o da janela

  ##= Cria��o dos grupos
  Groupbuttons <- ggroup(container = winsimpson, horizontal=FALSE)
  Groupgraphic <- ggroup(container = winsimpson, horizontal=FALSE)

  ##= Cria��o dos frames
  buttonsFrame <- gframe("Dados de Entrada", container = Groupbuttons, horizontal = FALSE)
  gbutton("Desenhe", cont= Groupbuttons, handler = integral)
  valueframe <- gframe("Resultados", container = Groupbuttons, hozizontal = TRUE, expand = TRUE)
  xk_output <- gtext("", container=valueframe, expand = TRUE)

  ##= Cria��o das op��es gr�ficas
  checkboxframe <- gframe("Op��es", container =Groupgraphic, horizontal = TRUE)
  glabel("Selecione antes do Plot", container= checkboxframe)
  pont <- gcheckbox("�ndices de x", checked = FALSE, cont =checkboxframe)
  pint <- gcheckbox("Pintar �rea", checked = TRUE, cont = checkboxframe)
  linvt <- gcheckbox("Linhas verticais", checked = TRUE, cont= checkboxframe)

  ##= Cria��o da �rea do plot principal
  mainGrapghFrame <- gframe("Gr�fico Principal", container = Groupgraphic)
  gg<-ggraphics(container = mainGrapghFrame, width = 650, height = 650)

  ##= �rea de entrada dos dados
  functionframe <- gframe("Fun��o", container = buttonsFrame, horizontal = TRUE)
  env_function<-gedit("",width = 50, cont = functionframe, initial.msg = "ex: 2*x + exp(x) - sin(x) + log(x)",expand = TRUE)

  intervalframe <- gframe("Intervalo", container = buttonsFrame, horizontal = TRUE)
  glabel("Intervalo no eixo x:", container = intervalframe)
  env_entr<-gedit("", width = 14,cont = intervalframe, initial.msg = "ex.: -2 3",expand = TRUE)

  stopframe <- gframe("Divis�es", container= buttonsFrame, horizontal=TRUE)
  glabel("N�mero de intervalos:", container = stopframe)
  env_div<-gedit("",width = 20, cont = stopframe, initial.msg = "ex.: 5",expand = TRUE)

  speedframe <- gframe("Velocidade da anima��o", container= buttonsFrame, horizontal=TRUE)
  glabel("Tempo em segundos:", container = speedframe)
  env_speed<-gedit("",width = 35, cont = speedframe, initial.msg = "Intervalo de tempo entre as itera��es",expand = TRUE)

  ##= cria��o do bot�o de sa�da
  exit_func<-function(h,...){dispose(winsimpson)}
  gbutton("SAIR", cont= Groupbuttons, handler = exit_func)

  ##= while utilizado na constru��o da anima��o
  while(isExtant(winsimpson)) Sys.sleep(1)

  ##= Mudar o �cone da janela
  #dir <- dirname(sys.frame(1)$ofile)
  #icon_dir <-paste0(dir, "/icon.png")
 # img <- gdkPixbufNewFromFile(icon_dir)
  #getToolkitWidget(winbissection)$setIcon(img$retval)
}
###########################################################################################
#' Interpola��o por Lagrange - Pontos:
#' Interpola polinomialmente um conjunto de pontos, e a partir da interpola��o obtida aproxima o valor da fun��o em um dado ponto.
#'
#' @param Valores_em_x As coordenadas no eixo x dos pontos utilizados na interpola��o, separados por espa�o e na ordem crescente, exemplo.: -9 -3 0.58 8 22
#' @param Valores_em_y As coordenadas no eixo y dos pontos utilizados na interpola��o, separados por espa�o, a quantidade de termos deve ser igual a do eixo x
#' @param Pto_aproximado valor de x para o qual a fun��o sera aproximada pela polin�mio interpolador
#' @param Intervalo_x Define qual o intervalo do plot no eixo x, separados por espa�o e na ordem crescente
#' @param OG_Indice Determina se os indices das aproxima��es obtidas em cada itera��o ser�o exibidos ou n�o
#' @param OG_Animacao Determina se a fun��o interpolada sera visualizada com anima��o ou sera plotada de uma so vez
#' @param OG_Linhas_Verticais  Determina se as linhas verticais ligando o ponto da fun��o no eixo x ser�o exibidas ou n�o
INTERPOLACAOPONTOS <-function()
{
  #== Mensagem inicial na �rea de resultados
  valuetextm <- "Aproxima��es obtidas"

  ##================================================================
  ##========== FUN��ES

  #==== Fun��o principal (que faz o m�todo)
  polinomial<- function(h,...)
  {
    #== Valores de entrada
    valaprm <- as.numeric(svalue(env_aprm))
    interentrx <- svalue(env_intervalx)
    interentry <- svalue(env_intervaly)
    xentr <- svalue(env_points_x)
    yentr <- svalue(env_points_y)

    #=== pegar os valores separados em x
    #
    valxaux <- as.list(strsplit(xentr," ")[[1]])
    contval <- length(valxaux) # contador da quantidade de valores de entrada, tanto x quanto para y
    valx <- c()
    for(i in 1:contval){
      valx[i] <- as.numeric(valxaux[i])
    }

    #=== pegar os valores separados em y
    #
    valyaux <- as.list(strsplit(yentr," ")[[1]])
    valy <- c()
    for(i in 1:contval){
      valy[i] <- as.numeric(valyaux[i])
    }

    #=== Pegas os extremos em x
    #
    interauxx <- as.list(strsplit(interentrx," ")[[1]])
    plotintervalx <- c()
    for(i in 1:2){
      plotintervalx[i] <- as.numeric(interauxx[i])
    }

    #=== Pegas os extremos em y
    #
    interauxy <- as.list(strsplit(interentry," ")[[1]])
    plotintervaly <- c()
    for(i in 1:2){
      plotintervaly[i] <- as.numeric(interauxy[i])
    }


    ##=== Criar o polin�mio de lagrange
    #
    lagrange <- rep(1,contval) # encher o vetor de 1, elemento neutro na multipl.
    for(j in 1:contval){ #======== for que termina o grau do polin�mio
      for(i in 1:contval){ #======= for para fazer cada L
        if(i!=j){ #===== If para n�o acontecer de de i==j
          lagrange[j] <- paste0(lagrange[j], "*", "(x -",valx[i],")/(", valx[j]-valx[i],")")
        }
      }
    }

    ##=== Juntar os yi com os li e montar o polin�mio
    polinomio <- 0
    for(i in 1:contval){
      polinomio <- paste(polinomio, "+",valy[i],"*",lagrange[i])
    }


    f_text <- paste("PolLagrange<- function(x){",polinomio,"}")# Criando string de entrada
    eval(parse(text=f_text))# Transformando o texto salvo na variavel ftext em uma express�o


    Valaprmy <- PolLagrange(valaprm)# Valor no polin�mio do ponto a ser aproximado

    #==== Plot do m�todo
    #
    #=Pontos m�ximos e m�nimos
    x_min <- plotintervalx[1]
    x_max <- plotintervalx[2]
    y_min <- plotintervaly[1]
    y_max <- plotintervaly[2]

    visible(gg) <- TRUE #Especificar que a �rea grafica gg recebe o gr�fico
    plot(valx, valy, xlim= c(x_min,x_max),ylim= c(y_min,y_max),  xlab ="Eixo x", ylab="Eixo y",col="blue", pch=1) #== plot dos pontos
    #abline(h=0, lty=2, col ="azure2")
    #abline(v=0, lty=2, col ="azure2")

    abline(h=0, lty=2)
    abline(v=0, lty=2)

    index <-c(0:(contval-1)) #= �ndicies dos pontos
    if(svalue(pont)){ #Caso seja marcado os �ndicies dos pontos no checkbox
      text(valx,valy, index, cex=0.65, pos=3, col="blue")
    }

    for (i in 1:(contval))
    {
      if(svalue(linvt)){ #Caso seja marcado as linhas verticais no checkbox
        segments(valx[i],0,valx[i],valy[i], col= "azure4", lty=2)
      }
    }


    ##= Plot do polin�mio de lagrange

    if(svalue(anim)){# Caso a op��o de anima��o esteja marcada
      kmax <- 100
      for(k in 1:kmax){ #desenhar o polin�mio com o tempo
        Sys.sleep(1/8)
        l <- (k-1)/(kmax -1)
        x0 <- x_min
        xk <- (1-l)*x_min + l*x_max

        curve(PolLagrange,xlim= c(x0, xk), col = "red", add = TRUE) #plot do polin�mio
      }
    }

    else{ #sem anima��o
      curve(PolLagrange,xlim= c(plotintervalx[1], plotintervalx[2]), col = "red", xlab="eixo x", ylab="eixo y", add = TRUE) #plot do polin�mio
    }


    ##==Plot do ponto aproximado
    Sys.sleep(2/3)
    segments(valaprm,0,valaprm,Valaprmy, col="azure4", lty = 2)
    points(valaprm, Valaprmy, col="chartreuse4", pch=9, cex=2)
    if(svalue(pont)){ #Caso seja marcado os indicies dos pontos no checkbox
      text(valaprm,Valaprmy, Valaprmy, cex=0.65, pos=3, col="chartreuse4")
    }

    #Resultados a serem mostrados ao usu�rio
    valuetextm <- paste0("Valor obtido pelo m�todo: ",Valaprmy,"\n")
    insert(xk_output,valuetextm)

  }


  #===========================================================================
  #INTERFACE
  winpolinomial <- gwindow("Interpola��o por Lagrange - Pontos ") #Cria��o da janela

  ##= Cria��o dos grupos
  Groupbuttons <- ggroup(container = winpolinomial, horizontal=FALSE)
  Groupgraphic <- ggroup(container = winpolinomial, horizontal=FALSE)

  ##= Cria��o dos frames
  buttonsFrame <- gframe("Dados de Entrada", container = Groupbuttons, horizontal = FALSE)
  gbutton("Desenhe", cont= Groupbuttons, handler = polinomial)
  valueframe <- gframe("Resultado", container = Groupbuttons, hozizontal = TRUE, expand = TRUE)
  xk_output <- gtext("", container=valueframe, expand = TRUE, width = 220, height = 100, expand=TRUE)

  ##= Cria��o das op��es graficas
  checkboxframe <- gframe("Op��es Gr�ficas", container =Groupgraphic, horizontal = TRUE)
  glabel("Selecione antes do Plot", container= checkboxframe)
  pont <- gcheckbox("�ndices de x", checked = FALSE, cont =checkboxframe)
  anim <- gcheckbox("Anima��o da fun��o", checked=TRUE, cont=checkboxframe)
  linvt <- gcheckbox("Linhas verticais", checked = TRUE, cont= checkboxframe)


  ##= Cria��o da �rea do plot
  mainGrapghFrame <- gframe("Grafico Principal", container = Groupgraphic)
  gg<-ggraphics(container = mainGrapghFrame, width = 650, height = 650)

  ##= �rea de entrada dos dados
  pointsframe <- gframe("Pontos", container = buttonsFrame, horizontal = FALSE)
  glabel("Valores em x", container = pointsframe)
  env_points_x<-gedit("",width = 50, cont = pointsframe, initial.msg = "Separados por espa�o",expand = TRUE)
  glabel("Valores em y", container = pointsframe)
  env_points_y<-gedit("", width = 50,cont = pointsframe, initial.msg = "Separados por espa�o",expand = TRUE)

  pointframe <- gframe("Aproxima��o", container= buttonsFrame, horizontal=TRUE)
  glabel("Ponto a ser aproximado", container = pointframe)
  env_aprm<-gedit("",width = 15, cont = pointframe, initial.msg = "ex.: 3.25",expand = TRUE)

  intervalframe <- gframe("Intervalo", container= buttonsFrame, horizontal=TRUE)
  glabel("Intervalo nos eixos: ", container = intervalframe)
  env_intervalx<-gedit("",width = 20, cont = intervalframe, initial.msg = "sobre o eixo x",expand = TRUE)
  env_intervaly<-gedit("",width = 20, cont = intervalframe, initial.msg = "Sobre o eixo y",expand = TRUE)

  ##= Cria��o do botao de saida
  exit_func<-function(h,...){dispose(winpolinomial)}
  gbutton("SAIR", cont= Groupbuttons, handler = exit_func)

  ##= while utilizado na constru��o da anima��o
  while(isExtant(winpolinomial)) Sys.sleep(1)

  ##= Mudar o �cone da janela
#  dir <- dirname(sys.frame(1)$ofile)
#  icon_dir <-paste0(dir, "/icon.png")
#  img <- gdkPixbufNewFromFile(icon_dir)
 # getToolkitWidget(winpolinomial)$setIcon(img$retval)
}
###########################################################################################
#' Interpola��o por Lagrange - Fun��o:
#' Interpola polinomialmente pontos de uma dada fun��o, e a partir da interpola��o obtida aproxima o valor da fun��o em um dado ponto.
#'
#' @param Funcao A fun��o que sera usada para dar os pontos em y e entao ser feita a interpola��o
#' @param Valores_em_x As coordenadas em x dos pontos utilizados na interpola��o, separados por espa�o e em ordem crescente, exemplo: -5.58 -1 2.2 8
#' @param Pto_aproximado Escolha de qual ponto quer ser aproximado a partir da aproxima��o pela interpola��o
#' @param Intervalo_x Define qual o intervalo do plot no eixo x, separados por espa�o e na ordem crescente
#' @param Intervalo_y Define qual o intervalo do plot no eixo y, separados por espa�o e na ordem crescente
#' @param OG_Indice Determina se os �ndices das aproxima��es obtidas em cada itera��o ser�o exibidos ou n�o
#' @param OG_Anima��o Determina se a fun��o interpolada sera visualizada com anima��o ou sera plotada de uma so vez
#' @param OG_Linhas_Verticais  Determina se as linhas verticais ligando o ponto da fun��o no eixo x ser�o exibidas ou n�o
INTERPOLACAOFUNCAO <-function()
{
  #== Mensagem inicial na �rea de resultados
  valuetextm <- "Aproxima��es obtidas"

  ##================================================================
  ##========== FUN��ES


  #==== Fun��o principal (que faz o m�todo)
  polinomial2 <- function(h,...)
  {
    #== Valores de entrada
    valaprm2 <- as.numeric(svalue(env_aprm2))
    interentrx2 <- svalue(env_intervalx2)
    interentry2 <- svalue(env_intervaly2)
    f <- svalue(env_function2)
    pointsentr <- svalue(env_points2)

    func <- paste("func <- function(x){",f,"}")# Criando string de entrada
    eval(parse(text=func))# Transformando o texto salvo na variavel ftext em uma expressao

    #=== pegar os valores separados em x
    #
    valxaux2 <- as.list(strsplit(pointsentr," ")[[1]])
    contval2 <- length(valxaux2) # contador da quantidade de valores de entrada, tanto x quanto para y
    valx2 <- c()
    for(i in 1:contval2){
      valx2[i] <- as.numeric(valxaux2[i])
    }

    #=== pegar os valores separados em y
    #
    valy2<-c()
    for(i in 1:contval2){
      valy2[i] <- func(valx2[i])
    }

    #=== Pegas os extremos em x
    #
    interauxx2 <- as.list(strsplit(interentrx2," ")[[1]])
    plotintervalx2 <- c()
    for(i in 1:2){
      plotintervalx2[i] <- as.numeric(interauxx2[i])
    }

    #=== Pegas os extremos em y
    #
    interauxy2 <- as.list(strsplit(interentry2," ")[[1]])
    plotintervaly2 <- c()
    for(i in 1:2){
      plotintervaly2[i] <- as.numeric(interauxy2[i])
    }


    ##=== Criar o polin�mio de lagrange
    #
    lagrange2 <- rep(1,contval2) # encher o vetor de 1, elemento neutro na multipl.
    for(j in 1:contval2){ # for que determina o grau do polin�mio
      for(i in 1:contval2){ # for para fazer cada L
        if(i!=j){ # If para n?o acontecer de de i==j
          lagrange2[j] <- paste0(lagrange2[j], "*", "(x -",valx2[i],")/(", valx2[j]-valx2[i],")")
        }
      }
    }

    ##=== Juntar os yi com os li e montar o polin�mio
    polinomio2 <- 0
    for(i in 1:contval2){
      polinomio2 <- paste(polinomio2, "+",valy2[i],"*",lagrange2[i])
    }

    f_text <- paste("PolLagrange2<- function(x){",polinomio2,"}")# Criando string de entrada
    eval(parse(text=f_text))# Transformando o texto salvo na variavel ftext em uma express�o

    Valaprmy2 <- PolLagrange2(valaprm2) # Valor no polin�mio do ponto a ser aproximado
    valrealy2 <- func(valaprm2) # Valor na fun��o do ponto a ser aproximado

    #==== Plot do m�todo
    #

    #=Pontos m�ximos e m�nimos
    x_min <- plotintervalx2[1]
    x_max <- plotintervalx2[2]
    y_min <- plotintervaly2[1]
    y_max <- plotintervaly2[2]

    visible(gg) <- TRUE #Agora a �rea grafica gg que ir� receber o plot
    plot(func, xlim=c(x_min,x_max), ylim= c(y_min,y_max),xlab=("Eixo x"),ylab=("Eixo y"), col="black")  #Plot da f(x)
    abline(h=0, lty=2)
    abline(v=0, lty=2)

    Sys.sleep(1/3)
    points(valx2,valy2, col="blue",pch=1)  #Plot dos pontos na f(x)

    if(svalue(pont)){ #Caso seja marcado os indicies dos pontos no checkbox
      index <-c(0:(contval2-1)) #= �ndicies dos pontos
      text(valx2,valy2, index, cex=0.65, pos=3, col="blue")
    }
    if(svalue(linvt)) {
      for (i in 1:(contval2)){ #Caso seja marcado as linhas verticais no checkbox
        segments(valx2[i],0,valx2[i],valy2[i], col= "azure4", lty=2)
      }
    }


    ##= Plot do polin�mio de lagrange

    if(svalue(anim)){# Caso a op��o de anima��o esteja marcada
      kmax <- 100
      for(k in 1:kmax){ #desenhar o polin�mio com o tempo
        Sys.sleep(1/8)
        l <- (k-1)/(kmax -1)
        x0 <- x_min
        xk <- (1-l)*x_min + l*x_max

        curve(PolLagrange2, xlim= c(x0, xk), col = "red", xlab="eixo x", ylab="eixo y", add = TRUE) #= plot do polinonmio
      }
    }
    else{ #sem anima��o
      curve(PolLagrange2, xlim= c(plotintervalx2[1], plotintervalx2[2]), col = "red", xlab="eixo x", ylab="eixo y", add = TRUE) #= plot do polin�mio
    }

    ##==Plot do ponto aproximado
    Sys.sleep(1/2)
    points(valaprm2, Valaprmy2, col="chartreuse4", pch=9) #=  valor no polin�mio
    text(valaprm2,Valaprmy2, Valaprmy2, cex=0.65, pos=3, col="chartreuse4")
    Sys.sleep(1/2)
    points(valaprm2, valrealy2, col="chartreuse4", pch=9) #= valor na f(x)
    text(valaprm2,valrealy2, valrealy2, cex=0.65, pos=3, col="chartreuse4")
    Sys.sleep(1/2)
    segments(valaprm2,Valaprmy2, valaprm2, valrealy2, col = "chartreuse4", lty=2)


    # Plot do zoom
    #
    if(Valaprmy2 < valrealy2){  # fazer com que a diferen�a fique centralizada
      yplot_min <- Valaprmy2
      yplot_max <- valrealy2
    }
    else{
      yplot_min <- valrealy2
      yplot_max <- Valaprmy2
    }

    visible(gg22) <- TRUE #agora a �rea grafica gg2 que ir� receber o plot
    par(mar = rep(2,4)) #margem

    plot(PolLagrange2, xlim= c(valaprm2 - 0.5, valaprm2 + 0.5), ylim= c(yplot_min - 0.5,yplot_max + 0.5), col="red")#plot do polin�mio
    points(valaprm2, Valaprmy2, col = "chartreuse4",  pch = 9) #= plot do ponto aproximado no polinimio
    points(valaprm2, valrealy2, col = "chartreuse4",  pch = 9) #= plot do ponto aproximado na f(c)
    segments(valaprm2, valrealy2, valaprm2, Valaprmy2, col = "chartreuse4") #= segmento de diferen�a entre os 2 pontos
    curve(func, col = "black", xlab="", ylab="", add= TRUE) #= plot fun��o dada

    if(svalue(pont)){ #Caso seja marcado os pontos no checkbox
      text(valx2,valy2,  index, cex=0.65, pos=3, col="blue")
    }

    #Resultados a serem mostrados ao usu�rio
    valerro <- (abs(Valaprmy2 - valrealy2)) # Calculo do erro absoluto
    valuetextm2 <- paste0("Valor obtido pelo m�todo: ",Valaprmy2,"\n", "Valor absoluto do erro: ",valerro)
    insert(xk_output2,valuetextm2)
  }


  #===========================================================================
  #INTERFACE
  winpolinomial <- gwindow("Interpola��o por Lagrange - Fun��o ") #Cria��o da janela

  ##= Cria��o dos grupos
  Groupbuttons2 <- ggroup(container = winpolinomial, horizontal=FALSE)
  Groupgraphic <- ggroup(container = winpolinomial, horizontal=FALSE)

  ##= Cria��o dos frames
  buttonsFrame <- gframe("Dados de Entrada", container = Groupbuttons2, horizontal = FALSE)
  gbutton("Desenhe", cont= Groupbuttons2, handler = polinomial2)
  valueframe2 <- gframe("Resultados", container = Groupbuttons2, hozizontal = TRUE, expand = TRUE)
  xk_output2 <- gtext("", container=valueframe2, expand = TRUE, width = 220, height = 60, expand = TRUE)

  ##= Cria��o das op��es gr�ficas
  checkboxframe <- gframe("Op��es Gr�ficas", container =Groupgraphic, horizontal = TRUE)
  glabel("Selecione antes do Plot", container= checkboxframe)
  pont <- gcheckbox("�ndices de x", checked = FALSE, cont =checkboxframe)
  anim <-gcheckbox("Anima��o da fun��o", checked=TRUE, cont=checkboxframe)
  linvt <- gcheckbox("Linhas verticais", checked = TRUE, cont= checkboxframe)

  ##= Cria��o da �rea do plot principal
  mainGrapghFrame <- gframe("Grafico Principal", container = Groupgraphic) #= gr�fico principal
  gg<-ggraphics(container = mainGrapghFrame, width = 650, height = 650) #= �rea grafia gg (principal)

  ##= �rea do zoom
  zoomGraphFrame2 <- gframe("Zoom do gr�fico principal", container = Groupbuttons2, horizontal = FALSE)
  gg22<-ggraphics(container = zoomGraphFrame2,  width = 220, height = 220)

  ##= �rea de entrada dos dados
  functionframe2 <- gframe("Fun��o", container = buttonsFrame, horizontal = TRUE)
  env_function2<-gedit("",width = 50, cont = functionframe2, initial.msg = "ex: 2*x + exp(x) - sin(x) + log(x)",expand = TRUE)

  pointsframe2 <- gframe("Pontos em x", container = buttonsFrame, horizontal = TRUE)
  glabel("Valores de x", container = pointsframe2)
  env_points2<-gedit("", width = 45,cont = pointsframe2, initial.msg = "Separados por espa�o",expand = TRUE)

  pointframe2 <- gframe("Aproxima��o", container= buttonsFrame, horizontal=TRUE)
  glabel("Ponto a ser aproximado", container = pointframe2)
  env_aprm2<-gedit("",width = 10, cont = pointframe2, initial.msg = "ex.: 4.23",expand = TRUE)

  intervalframe2 <- gframe("Intervalo", container= buttonsFrame, horizontal=TRUE)
  glabel("Intervalo nos eixos: ", container = intervalframe2)
  env_intervalx2<-gedit("",width = 20, cont = intervalframe2, initial.msg = "sobre o eixo x",expand = TRUE)
  env_intervaly2<-gedit("",width = 20, cont = intervalframe2, initial.msg = "Sobre o eixo y",expand = TRUE)

  #== Cria��o do botao de sa�da
  exit_func<-function(h,...){dispose(winpolinomial)} #= fun��o de saida
  gbutton("SAIR", cont= Groupbuttons2, handler = exit_func) #= bot�o de saida

  ##= while utilizado na constru��o da anima��o
  while(isExtant(winpolinomial)) Sys.sleep(1)

  ##= Mudar o �cone da janela
  #dir <- dirname(sys.frame(1)$ofile)
  #icon_dir <-paste0(dir, "/icon.png")
 # img <- gdkPixbufNewFromFile(icon_dir)
  #getToolkitWidget(winpolinomial)$setIcon(img$retval)
}
###########################################################################################
#' Aproxima��o por Taylor:
#' Obtem uma aproxima��o local para dada fun��o, atrav�s da constru��o dos polinomios de Taylor
#'
#' Atraves da derivada de um ponto dado de uma fun��o sao interpolados polinomios de grau 1 a 5 para aproximar um outro ponto
#'
#' @param Funcao A que ser utilizada como base
#' @param Pto_usado Ponto que sera utilizado para pegar a derivada e aproximar as interpola��es
#' @param Pto_aproximado Escolha de qual ponto quer ser aproximado a partir da aproxima��o pela interpola��o
#' @param Intervalo_x Define qual o intervalo do plot no eixo x, separados por espa�o e na ordem crescente
#' @param Tempo Define o tempo entre cada interpola��o
#' @param OG_Grau Seleciona quais grais ser�o feitos e plotados
TAYLOR <-function()
{
  #== Mensagem inicial na �rea de resultados
  valuetextm <- "Aproxima��es obtidas"

  ##================================================================
  ##========== FUN��ES

  #==== Fun��o principal (que faz o m�todo)
  taylorfun<- function(h,...)
  {
    #== Valores de entrada
    f<-svalue(env_function)
    valapr<-as.numeric(svalue(env_entr))
    valenv <- as.numeric(svalue(env_val))
    limix <- svalue(env_limx)
    speed<-as.numeric(svalue(env_speed))

    #============== pegar os valores separados em x =======
    interaux <- as.list(strsplit(limix," ")[[1]])
    limitx <- c()
    for(i in 1:2){
      limitx[i] <- as.numeric(interaux[i])
    }


    # Criando strings de entrada
    func <- paste("func <- function(x){",f,"}")
    func2 <- paste("func2 <- expression(",f,")")

    # Transformando o texto em uma express�o
    eval(parse(text=func))
    eval(parse(text=func2))

    #=============== Fun��es derivadas===============
    DevFunc1 <- function(x){eval(D(func2,"x"))}
    DevFunc2 <- function(x){eval(D(D(func2,"x"),"x"))}
    DevFunc3 <- function(x){eval(D(D(D(func2,"x"),"x"),"x"))}
    DevFunc4 <- function(x){eval(D(D(D(D(func2,"x"),"x"),"x"),"x"))}
    DevFunc5 <- function(x){eval(D(D(D(D(D(func2,"x"),"x"),"x"),"x"),"x"))}


    #Vetor com o valores que ser�o uzados de f^n(a) que ser�o ulizados no polin�mio
    fnval <- c()
    fnval[1] <- DevFunc1(valapr)
    fnval[2] <- DevFunc2(valapr)
    fnval[3] <- DevFunc3(valapr)
    fnval[4] <- DevFunc4(valapr)
    fnval[5] <- DevFunc5(valapr)

    #Vetor que receber� cada polin�mio
    fnpol <- c()
    for(i in 1:5){
      if(i!=1){
        fnpol[i] <- paste0(fnpol[i-1],"+(",(fnval[i]/(factorial(i))),")*((x-",valapr,")^",i,")")
      }
      else{
        fnpol[i] <- paste0(func(valapr),"+(",(fnval[i]/(factorial(i))),")*((x-",valapr,")^",i,")")
      }
    }

    #==== Plot do m�todo
    #
    visible(gg) <- TRUE #Agora a �rea grafica gg que ir� receber o plot
    par(xpd = T, mar = c(0,0,0.5,5)) #= margem
    plot(func, limitx[1],limitx[2], col = "red", lwd= 3,xaxt='n',yaxt='n',ann=FALSE,bty='n') #Plot da f(x)
    legend(limitx[2] +(limitx[2]-limitx[1])*0.06, func(limitx[2]), c("Grau 1", "Grau 2", "Grau 3", "Grau 4", "Grau 5"),col = c("chartreuse3", "aquamarine3", "coral3", "deeppink2","midnightblue"),cex = 0.8,lwd = 1, lty = 1) #= legenda
    abline(h=0, lty=2)
    abline(v=0, lty=2)

    #======= Plot dos polinomios de taylor
    #
    #==== Caso o grau n�o seja marcado come�ar como nulo
    resulpol1 <- ""
    resulpol2 <- ""
    resulpol3 <- ""
    resulpol4 <- ""
    resulpol5 <- ""
    #==============

    if(svalue(grau1)){
      Sys.sleep(speed) #Anima��o
      #===== Plot
      Fpoli <- fnpol[1]
      poli1 <- paste("poli1 <-function(x){",Fpoli,"}")
      eval(parse(text=poli1))
      curve(poli1, type="l", add=TRUE, col= "chartreuse3")
      #===== Plot do ponto no polin�mio
      points(valenv, poli1(valenv), col="blue", pch = 1)
      #===== Colocar o resultado na janela
      resulpol1 <- paste0("\n","No grau 1: ",poli1(valenv))
    }
    if(svalue(grau2)){
      Sys.sleep(speed)
      Fpoli <- fnpol[2]
      poli2 <- paste("poli2 <-function(x){",Fpoli,"}")
      eval(parse(text=poli2))
      curve(poli2, type="l", add=TRUE, col ="aquamarine3")
      points(valenv, poli2(valenv), col="blue", pch = 1)
      resulpol2 <- paste0("\n","No grau 2: ",poli2(valenv))
    }
    if(svalue(grau3)){
      Sys.sleep(speed)
      Fpoli <- fnpol[3]
      poli3 <- paste("poli3 <-function(x){",Fpoli,"}")
      eval(parse(text=poli3))
      curve(poli3, type="l", add=TRUE, col="coral3")
      points(valenv, poli3(valenv), col="blue", pch = 1)
      resulpol3 <- paste0("\n","No grau 3: ",poli3(valenv))
    }
    if(svalue(grau4)){
      Sys.sleep(speed)
      Fpoli <- fnpol[4]
      poli4 <- paste("poli4 <-function(x){",Fpoli,"}")
      eval(parse(text=poli4))
      curve(poli4, type="l", add=TRUE, col="deeppink2")
      points(valenv, poli4(valenv), col="blue", pch = 1)
      resulpol4 <- paste0("\n","No grau 4: ",poli4(valenv))
    }
    if(svalue(grau5)){
      Sys.sleep(speed)
      Fpoli <- fnpol[5]
      poli5 <- paste("poli5 <-function(x){",Fpoli,"}")
      eval(parse(text=poli5))
      curve(poli5, type="l", add=TRUE, col="midnightblue")
      points(valenv, poli5(valenv), col="blue", pch = 1)
      resulpol5 <- paste0("\n","No grau 5: ",poli5(valenv))
    }

    #==== Guardar o resultado na vari�vel e plotar
    resul <- func(valenv)
    points(valenv, resul, pch=3)

    #Resultados a serem mostrados ao usu�rio
    valuetextm <- paste0("\n","O valor na fun��o: ",resul,resulpol1,resulpol2,resulpol3,resulpol4,resulpol5)
    insert(xk_output,valuetextm)

  }

  #===========================================================================
  #INTERFACE
  wintaylor <- gwindow("Aproxima��o por Taylor") #Cria��o da janela

  ##= Cria��o dos grupos
  Groupbuttons <- ggroup(container = wintaylor, horizontal=FALSE)
  Groupgraphic <- ggroup(container = wintaylor, horizontal=FALSE)

  ##= Cria��o dos frames
  buttonsFrame <- gframe("Dados de Entrada", container = Groupbuttons, horizontal = FALSE)
  gbutton("Desenhe", cont= Groupbuttons, handler = taylorfun)
  valueframe <- gframe("Resultados", container = Groupbuttons, hozizontal = TRUE, expand = TRUE)
  xk_output <- gtext("", container=valueframe, width = 220, expand=TRUE)

  ##= Cria��o das op��es graficas
  checkboxframe <- gframe("Op��es Gr�ficas", container =Groupgraphic, horizontal = TRUE)
  glabel("Grau do polin�mio", container= checkboxframe)
  grau1 <- gcheckbox("Grau 1", checked = TRUE, cont = checkboxframe)
  grau2 <- gcheckbox("Grau 2", checked = TRUE, cont = checkboxframe)
  grau3 <- gcheckbox("Grau 3", checked = TRUE, cont = checkboxframe)
  grau4 <- gcheckbox("Grau 4", checked = FALSE, cont = checkboxframe)
  grau5 <- gcheckbox("Grau 5", checked = FALSE, cont = checkboxframe)

  ##= Cria��o da �rea do plot
  mainGrapghFrame <- gframe("Grafico Principal", container = Groupgraphic)
  gg<-ggraphics(container = mainGrapghFrame, width = 650, height = 650)

  ##= �rea de entrada dos dados
  functionframe <- gframe("Fun��o", container = buttonsFrame, horizontal = TRUE)
  env_function<-gedit("", cont = functionframe, initial.msg = "ex: 2*x + exp(x) - sin(x) + log(x)",expand = TRUE)

  intervalframe <- gframe("Aproxima��o", container = buttonsFrame, horizontal = TRUE)
  glabel("Ponto a ser usado:", container = intervalframe)
  env_entr<-gedit("", width = 7,cont = intervalframe, initial.msg = "ex.: 0",expand = TRUE)
  glabel("Ponto a ser aproximado:", container = intervalframe)
  env_val<-gedit("", width = 7,cont = intervalframe, initial.msg = "ex.: 0.75",expand = TRUE)

  stopframe <- gframe("Limites", container= buttonsFrame, horizontal=TRUE)
  glabel("Limite em x:", container = stopframe)
  env_limx<-gedit("",width = 15, cont = stopframe, initial.msg = "ex.: -5 5",expand = TRUE)

  speedframe <- gframe("Velocidade da anima��o", container= buttonsFrame, horizontal=TRUE,expand = TRUE)
  glabel("Tempo em segundos:", container = speedframe)
  env_speed<-gedit("", cont = speedframe, initial.msg = "Intervalo de tempo entre as itera��es", expand = TRUE)

  ##= cria��o do bot�o de saida
  exit_func<-function(h,...){dispose(wintaylor)}
  gbutton("SAIR", cont= Groupbuttons, handler = exit_func)

  ##= while utilizado na constru��o da anima��o
  while(isExtant(wintaylor)) Sys.sleep(1)

  ##= Mudar o �cone da janela
  #dir <- dirname(sys.frame(1)$ofile)
 # icon_dir <-paste0(dir, "/icon.png")
 # img <- gdkPixbufNewFromFile(icon_dir)
  #getToolkitWidget(winbissection)$setIcon(img$retval)
}


JANELAPRINCIPAL<-function(...)
{

    linkfun <- function(h,...){
        browseURL("http://liscustodio.github.io/CnVisual")
    }

    choose <- c("- - - - - - - - - - - - - - - -","Zero de fun��es:", "   M�todo da Bisse��o","   M�todo da Falsa Posi��o", "   M�todo de Newton-Raphson", "   M�todo da Secante",
    "Interpola��o:","   Polin�mios de Lagrange (Fun��o como entrada)","   Polin�mios de Lagrange (Pontos como entrada)","Aproxima��o:","   Polin�mios de Taylor",
    "Integra��o:" ,"   M�todo dos Trap�zios","   M�todo de Simpson")
    open <- function(h,...)
    {
        if((svalue(h$obj))==choose[3]) {BISSECAO()}
        if((svalue(h$obj))==choose[4]) {FALSAPOSICAO()}
        if((svalue(h$obj))==choose[5]) {NEWTONRAPSON()}
        if((svalue(h$obj))==choose[6]) {SECANTE()}
        if((svalue(h$obj))==choose[8]) {INTERPOLACAOFUNCAO()}
        if((svalue(h$obj))==choose[9]) {INTERPOLACAOPONTOS()}
        if((svalue(h$obj))==choose[11]) {TAYLOR()}
        if((svalue(h$obj))==choose[13]) {TRAPEZIOS()}
        if((svalue(h$obj))==choose[14]) {SIMPSON()}
    }

    MainWindow <- gwindow(title = "CN Visual",width = 300, height = 300, horizontal = FALSE)
    maingroup <- ggroup(horizontal=FALSE, container=MainWindow)
    checkframe <- gframe("Selecione o m�todo", container = maingroup, horizontal = FALSE)
    Metodo <- gcombobox( choose, container= checkframe, handler=open, horizontal = FALSE, height=150)
    bottomframe <- gframe("Aten��o", container = maingroup, horizontal = FALSE)
    Texto <- glabel("", container = bottomframe)
   # Texto <- glabel("Por favor, leia o manual antes de utilizar o software \ne verifique se n�o h� uma versao mais recente, \n ambos podem ser encontrados no site, \n basta clicar no botao a baixo", container = bottomframe)
    Texto <- glabel("Para ter acesso �s informa��es sobre o pacote e suas \nfuncionalidades digite: help(package = CNVisual)", container = bottomframe)
    Texto <- glabel("", container = bottomframe)
    gbutton("Ir para o site", cont= maingroup, handler = linkfun)

    #img <- gdkPixbufNewFromFile("icon.png")
    #getToolkitWidget(MainWindow)$setIcon(img$retval)

    exit_hand<-function(h,...){dispose(MainWindow)}
    gbutton("SAIR", cont= maingroup, handler = exit_hand)
}
